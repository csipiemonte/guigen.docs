package it.csi.modlogext.modlogext.presentation.modlogext.action;

import java.util.Map;
import java.util.HashMap;

public class PDefStateCommand implements ICommand {

	// il serial version uid e' fisso in quanto la classe in oggetto e' serializzabile
	// solo per poter essere inserita in sessione web e non viene scambiata con altre
	// componenti.
	private static final long serialVersionUID = 1L;

	String _containerName = null;
	String _stateName = null;
	String[] _widgetsOn = null;
	String[] _widgetsOff = null;
	String[] _widgetsShown = null;
	String[] _widgetsHidden = null;

	public PDefStateCommand(String containerName, String stateName,
			String widgetsOn[], String widgetsOff[], String widgetsShown[],
			String widgetsHidden[]) {
		_containerName = containerName;
		_stateName = stateName;
		_widgetsOn = widgetsOn;
		_widgetsOff = widgetsOff;
		_widgetsShown = widgetsShown;
		_widgetsHidden = widgetsHidden;
	}

	/**
	 * La logica &egrave; l astessa di ScreenStateCommand, poich&egrave; i nomi dei widget sono espansi
	 * all'inizializzazione del comando.
	 */
	public String doCommand(BaseAction strutsAction)
			throws CommandExecutionException {
		OnOffCommand turnOn = new OnOffCommand(_containerName, _widgetsOn, true);
		OnOffCommand turnOff = new OnOffCommand(_containerName, _widgetsOff,
				false);
		VisibilityCommand show = new VisibilityCommand(_containerName,
				_widgetsShown, true);
		VisibilityCommand hide = new VisibilityCommand(_containerName,
				_widgetsHidden, false);
		turnOn.doCommand(strutsAction);
		turnOff.doCommand(strutsAction);
		show.doCommand(strutsAction);
		hide.doCommand(strutsAction);
		if (_stateName != null) {
			strutsAction.getSession().put(_containerName + "_currentState",
					_stateName);
		}
		return null;
	}
}
