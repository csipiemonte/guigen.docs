package it.csi.modlogext.modlogext.presentation.modlogext.action;

import java.util.*;

import com.opensymphony.xwork2.ActionContext;

import it.csi.modlogext.modlogext.dto.*;

/**
 * LogoutAction Action Class.
 *
 * @author GuiGen
 */
public class LogoutAction extends BaseAction<BaseSessionAwareDTO> {

	public BaseSessionAwareDTO getModel() {
		throw new UnsupportedOperationException(
				"Metodo getModel() intenzionalmente non implementato.");
	}

	public void setModel(BaseSessionAwareDTO modello) {
		throw new UnsupportedOperationException(
				"Metodo setModel() intenzionalmente non implementato..");
	}

	/**
	 * nessuna classe model associata
	 */
	public Class modelClass() {
		return null;
	}

	/**
	 * Mostra la pagina di conferma del logout
	 * @return SSO_LOGOUT.
	 */
	public String confirmLogout() throws Exception {
		return "confirmLogout";
	}

	protected void dumpModel(boolean pre) {
		// metodo intenzionalmente vuoto
	}

	protected void doBeforeEventCommand() {
		// non sono previsti before/after event commands
	}

	protected void doAfterEventCommand() {
		// non sono previsti before/after event commands
	}

	protected ICommand initCommand(String widgName, String eventName) {
		// metodo intenzionalmente vuoto
		return null;
	}

	/**
	 *
	 * @return SSO_LOGOUT.
	 */
	public String ssoLogout() throws Exception {
		log.debug("[LogoutAction::ssoLogout] START");
		invalidateLocalSession();
		log.debug("[LogoutAction::ssoLogout] END");
		return "SSO_LOGOUT";
	}

	/**
	 *
	 * @return LOCAL_LOGOUT.
	 */
	public String localLogout() throws Exception {
		log.debug("[LogoutAction::localLogout] START");
		invalidateLocalSession();
		log.debug("[LogoutAction::localLogout] END");
		return "LOCAL_LOGOUT";
	}

	/**
	 * Invalida la sessione corrente
	 */
	protected void invalidateLocalSession() {

	}

	/**
	 *	Metodo per la rimozione dalla sessione degli application data a scope
	 *  SAME_PAGE. 
	 */
	public void clearPageScopedAppData(String targetContentPanelName) {
		//NOP
	}

}
