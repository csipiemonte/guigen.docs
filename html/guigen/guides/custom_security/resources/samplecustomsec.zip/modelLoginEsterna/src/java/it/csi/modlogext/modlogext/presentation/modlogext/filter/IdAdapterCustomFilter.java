package it.csi.modlogext.modlogext.presentation.modlogext.filter;

import it.csi.iride2.policy.entity.Identita;
import it.csi.iride2.policy.exceptions.MalformedIdTokenException;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import it.csi.modlogext.modlogext.util.*;

/**
 * Inserisce in sessione l'oggetto <code>currentUser</code>
 * Funge da adapter tra il filter del metodo di autenticaizone previsto e la
 * logica applicativa.
 *
 * @author CSIPiemonte
 */

public class IdAdapterCustomFilter implements Filter {

	public static final String USERINFO_SESSIONATTR = "appDatacurrentUser";
	public final static String TICKET = "myTicketSource";
	public static final String SECURITY_SESSION_MARKER = "iride2_id";

	protected static final Logger log = Logger //NOSONAR  Reason:EIAS
			.getLogger(Constants.APPLICATION_CODE + ".security"); //NOSONAR  Reason:EIAS

	public static String loginPage;

	public void doFilter(ServletRequest req, ServletResponse resp,
			FilterChain fchn) throws IOException, ServletException {
		HttpServletRequest hreq = (HttpServletRequest) req;
		Object marker = getMarker(hreq);

		if (hreq.getRequestURI().indexOf(loginPage) > -1) {
			fchn.doFilter(req, resp);
			return;
		}

		if (marker != null)
			fchn.doFilter(req, resp);
		else {
			validateTicket(hreq);
			fchn.doFilter(req, resp);
		}
	}

	private Object getMarker(HttpServletRequest hreq) {
		return hreq.getSession().getAttribute(SECURITY_SESSION_MARKER);
	}

	private Object getTicket(HttpServletRequest hreq) {
		return hreq.getParameter(TICKET);
	}

	/**
	 * Estrae dalla REQUEST_PARAM il ticket (nel parametro "myTicketSource") e lo valida
	 * Se la validazione ha avuto successo allora da questo ricava l' identità digitale necessaria per il livello autorizzativo.
	 * Inserisce in sessione l' identità digitale (nel paramentro "iride2_id")
	 * Crea e inserisce in sessione il currentUser (nel paramentro "appDatacurrentUser")
	 * @param hreq
	 * @throws ServletException --> 
	 */
	private void validateTicket(HttpServletRequest hreq)
			throws ServletException {
		Identita identita = null;
		Object ticket = getTicket(hreq);

		String encodedUserInfo = extractEncodedUserInfo(ticket);
		String normalizedTicket = normalizeEncodedUserInfo(encodedUserInfo);
		try {
			identita = new Identita(normalizedTicket);
		} catch (MalformedIdTokenException e) {
			e.printStackTrace();
		}

		if (identita != null) {
			hreq.getSession().setAttribute(SECURITY_SESSION_MARKER, identita);
			createCurrentUser(hreq);
		} else
			throw new ServletException(
					"Tentativo di accesso a pagina non home e non di servizio senza token di sicurezza");

	}

	/**
	 * Costruisce l' oggetto UserInfo per tenere traccia dell' utente loggato
	 * @param hreq
	 */
	private void createCurrentUser(HttpServletRequest hreq) {

		Identita identita = (Identita) hreq.getSession().getAttribute(
				SECURITY_SESSION_MARKER);
		it.csi.modlogext.modlogext.dto.common.UserInfo userInfo = new it.csi.modlogext.modlogext.dto.common.UserInfo();

		userInfo.setNome(identita.getNome());
		userInfo.setCognome(identita.getCognome());
		userInfo.setCodFisc(identita.getCodFiscale());
		userInfo.setIdIride(identita.toString());

		/*PROTECTED REGION ID(R-1570805584) ENABLED START*/
		/*PROTECTED REGION END*/

		hreq.getSession().setAttribute(USERINFO_SESSIONATTR, userInfo);

	}

	/**
	 * Rielaborare (se necessario) la stringa encodedUserInfo per ottenerne una del tipo:
	 * C.F./NOME/COGNOME/ID_PROVIDER/MAC/LIV_AUTENTICAZIONE/TIMESTAMP
	 * @param encodedUserInfo
	 * @return String token normalizzato
	 */
	private String normalizeEncodedUserInfo(String encodedUserInfo) {
		String res = encodedUserInfo;

		/*PROTECTED REGION ID(R-18038930) ENABLED START*/
		/*PROTECTED REGION END*/

		return res;
	}

	private String extractEncodedUserInfo(Object ticket) {
		String res = null;

		/*PROTECTED REGION ID(R-482995998) ENABLED START*/
		res = (String) ticket;
		/*PROTECTED REGION END*/

		return res;
	}

	public void destroy() {
		// NOP
	}

	public void init(FilterConfig config) throws ServletException {
		loginPage = config.getInitParameter("loginPage");
	}

}
