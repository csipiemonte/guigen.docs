package it.csi.modlogext.modlogext.presentation.modlogext.action;

import java.util.Map;
import java.util.HashMap;

/**
 * Implementazione dle comando VisibilityCommand
 */
public class VisibilityCommand implements ICommand {

	// il serial version uid e' fisso in quanto la classe in oggetto e' serializzabile
	// solo per poter essere inserita in sessione web e non viene scambiata con altre
	// componenti.
	private static final long serialVersionUID = 1L;

	/**
	 * nome dell'attributo in sessione che contiene la mappa di visibilita' dei menu
	 */
	private static final String SESSION_MENU_VISIBILITY = "menuVisibilityMap";

	/**
	 * containerName
	 */
	String _containerName = null;

	/**
	 * targetsWidgets
	 */
	String[] _targetsWidgets = null;

	/**
	 * targetsMenuElement
	 */
	String[] _targetsMenuElement = null;

	/**
	 * show?
	 */
	boolean _show = true;

	/**
	 * @param containerName il nome del content panel che contiene i widget da mostrare/nascondere
	 * @param targetWidgets nomi dei widget da mostrare/nascondere
	 * @param targetsMenuElement nomi dei menu da mostrare/nascondere
	 * @param show se vale true i widget/menu saranno abilitati, altrimenti saranno disabilitati
	 */
	public VisibilityCommand(String containerName, String targetsWidgets[],
			String targetsMenuElement[], boolean show) {
		_containerName = containerName;
		_targetsWidgets = targetsWidgets;
		_targetsMenuElement = targetsMenuElement;
		_show = show;
	}

	/**
	 * @param containerName il nome del content panel che contiene i widget da mostrare/nascondere
	 * @param targetWidgets nomi dei widget da mostrare/nascondere
	 * @param show se vale true i widget/menu saranno abilitati, altrimenti saranno disabilitati
	 */
	public VisibilityCommand(String containerName, String targetsWidgets[],
			boolean show) {
		_containerName = containerName;
		_targetsWidgets = targetsWidgets;
		_show = show;
	}

	/**
	 * esecuzione del comando VisibilityCommand. Lo stato di visibilita' dei widget/menu e' contenuto in
	 * sessione.
	 */
	public String doCommand(BaseAction strutsAction)
			throws CommandExecutionException {

		//Definzione Visibility Widgets per ContentPanel
		if (_targetsWidgets != null) {
			// lo stato di visibilita' dei widget e' mantenuto in sessione
			// in una mappa a due livelli:
			// - il primo livello contiene <nome cp, mappa per il cp>
			// - il secondo livello contiene <[widget]_visible, true|false>
			Map<String, Boolean> cpWidgetsStatus = (Map<String, Boolean>) strutsAction.session
					.get(_containerName);
			if (cpWidgetsStatus == null) {
				cpWidgetsStatus = new HashMap<String, Boolean>();
				strutsAction.session.put(_containerName, cpWidgetsStatus);
			}
			for (int i = 0; i < _targetsWidgets.length; i++) {
				cpWidgetsStatus.put(_targetsWidgets[i] + "_visible",
						Boolean.valueOf(_show));
			}

		}

		//Definzione Visibility MenuElement 
		if (_targetsMenuElement != null) {
			// lo stato di visibilita' di una voce di menu e' contenuta in sessione
			// in una mappa
			Map<String, Boolean> menuVisibilityMap = (Map<String, Boolean>) strutsAction.session
					.get(SESSION_MENU_VISIBILITY);

			if (menuVisibilityMap == null) {
				// se la mappa non esiste ancora la creo
				menuVisibilityMap = new HashMap<String, Boolean>();
				strutsAction.session.put(SESSION_MENU_VISIBILITY,
						menuVisibilityMap);
			}
			// inserisco lo stato di visibilita' di tutti i target menu
			// inserendo la coppia <[menu]_visible, true|false>
			for (int i = 0; i < _targetsMenuElement.length; i++) {
				menuVisibilityMap.put(_targetsMenuElement[i] + "_visible",
						Boolean.valueOf(_show));
			}
		}
		return null;
	}
}
