package it.csi.modlogext.modlogext.presentation.modlogext.validator;

import com.opensymphony.xwork2.validator.ValidationException;
import com.opensymphony.xwork2.validator.validators.AbstractRangeValidator;

/**
 * Controlla il valore del campo di tipo Long sia contenuto nel range atteso
 *
 * @author GuiGen
 */
public class CsiLongRangeValidator extends AbstractRangeValidator {

	/**
	 * max
	 */
	private Long max = null;

	/**
	 * min
	 */
	private Long min = null;

	/**
	 * max
	 */
	public void setMax(Long max) {
		this.max = max;
	}

	/**
	 * max
	 */
	public Long getMax() {
		return max;
	}

	/**
	 * maxComparatorValue
	 */
	@SuppressWarnings("unchecked")
	public Comparable getMaxComparatorValue() {
		return max;
	}

	/**
	 * min
	 */
	public void setMin(Long min) {
		this.min = min;
	}

	/**
	 * min
	 */
	public Long getMin() {
		return min;
	}

	/**
	 * minComparatorValue
	 */
	@SuppressWarnings("unchecked")
	public Comparable getMinComparatorValue() {
		return min;
	}

	/**
	 * validazione effettiva
	 * @param object
	 */
	@Override
	public void validate(Object object) throws ValidationException {
		String fieldName = getFieldName();
		Long value = (Long) this.getFieldValue(fieldName, object);
		if (getMin() > value || (getMax() != null && getMax() < value)) {
			addFieldError(fieldName, object);
		}
	}

}
