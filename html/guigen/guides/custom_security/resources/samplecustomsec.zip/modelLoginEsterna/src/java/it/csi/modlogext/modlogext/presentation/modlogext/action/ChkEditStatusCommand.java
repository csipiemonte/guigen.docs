package it.csi.modlogext.modlogext.presentation.modlogext.action;

/**
 * Implementazione del comando ChkEditStatusCommand. Permette di esaminare se il valore
 * di un ApplicationData coinvolto in una sessione di editing (tramite BeginEditSessionCommand)
 * e' stato modificato.
 */
public class ChkEditStatusCommand implements ICommand {

	// il serial version uid e' fisso in quanto la classe in oggetto e' serializzabile
	// solo per poter essere inserita in sessione web e non viene scambiata con altre
	// componenti.
	private static final long serialVersionUID = 1L;

	ICommand _doIfChanged;
	ICommand _doIfNotChanged;
	String _checkAggr;
	String[] _checkedData;

	/**
	 * @param checkedData il nome deli application data da esaminare
	 * @param checkAggregation modalita' di aggregazione dei risultati dei singoli check.
	 * puo' valere "AND", "OR" o "XOR"
	 * @param doIfChanged ICommand da eseguire se il check e' positivo (dati variati)
	 * @param doIfNotChanged ICommand da eseguire se il check e' negativo (dati non variati) 
	 */
	public ChkEditStatusCommand(String[] checkedData, String checkAggregation,
			ICommand doIfChanged, ICommand doIfNotChanged) {
		_checkedData = checkedData;
		_checkAggr = checkAggregation;
		_doIfChanged = doIfChanged;
		_doIfNotChanged = doIfNotChanged;
	}

	/**
	 * Esecuzione del comando. 
	 * A seconda del risultato del check (che tiene conto del tipo di aggregazione)
	 * viene eseguito il comando contenuto in doIfChanged o doIfNotchanged
	 */
	public String doCommand(BaseAction strutsAction)
			throws CommandExecutionException {
		boolean changed = checkAppdata4Changes(_checkedData, _checkAggr,
				strutsAction);
		if (changed)
			return _doIfChanged.doCommand(strutsAction);
		else
			return _doIfNotChanged.doCommand(strutsAction);
	}

	/**
	 * Verifica variazioni sugli appdata con la politica di aggregazione specificata
	 * @param checkedData
	 * @param checkAggr
	 * @param strutsAction
	 * @return
	 */
	boolean checkAppdata4Changes(String[] checkedData, String checkAggr,
			BaseAction strutsAction) {
		if (checkedData == null || checkedData.length == 0)
			return false;
		// else
		boolean ris = "OR".equals(checkAggr) ? false : ("AND".equals(checkAggr)
				? true
				: false);
		for (int i = 0; i < checkedData.length; i++) {
			String currADName = checkedData[i];
			boolean currChanged = checkAppdata4Changes(currADName, strutsAction);
			if (currChanged && "OR".equals(checkAggr))
				return true; // al primo esco con true
			else if (!currChanged && "AND".equals(checkAggr))
				return false; // al primo falso esco con falso
			else if ("XOR".equals(checkAggr)) {
				if (currChanged && ris)
					return false; // secondo match: rompe lo xor
			}
		}
		return ris;
	}

	/**
	 * verifica se il singolo appdata e' variato
	 * @param currADName
	 * @param strutsAction
	 * @return
	 */
	private boolean checkAppdata4Changes(String currADName,
			BaseAction strutsAction) {
		Object adVal = strutsAction.getSession().get(currADName);
		Object adBkp = strutsAction.getSession().get(currADName + "_bckp");
		if (adBkp != null) {
			it.csi.modlogext.modlogext.dto.DTOUtils dtoUtils = it.csi.modlogext.modlogext.dto.DTOUtils
					.getInstance();
			return !(dtoUtils.deepEquals(adVal, adBkp));
		} else
			return false;
	}

};
