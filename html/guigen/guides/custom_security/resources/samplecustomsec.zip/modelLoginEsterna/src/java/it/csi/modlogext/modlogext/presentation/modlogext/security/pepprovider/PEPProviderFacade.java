package it.csi.modlogext.modlogext.presentation.modlogext.security.pepprovider;
import it.csi.csi.wrapper.SystemException;
import it.csi.csi.wrapper.UnrecoverableException;
import it.csi.iride2.iridefed.entity.Ruolo;
import it.csi.iride2.iridefed.exceptions.BadRuoloException;
import it.csi.iride2.policy.entity.Actor;
import it.csi.iride2.policy.entity.Application;
import it.csi.iride2.policy.entity.Identita;
import it.csi.iride2.policy.entity.UseCase;
import it.csi.iride2.policy.exceptions.AuthException;
import it.csi.iride2.policy.exceptions.CertOutsideValidityException;
import it.csi.iride2.policy.exceptions.CertRevokedException;
import it.csi.iride2.policy.exceptions.IdProviderNotFoundException;
import it.csi.iride2.policy.exceptions.IdentitaNonAutenticaException;
import it.csi.iride2.policy.exceptions.InternalException;
import it.csi.iride2.policy.exceptions.MalformedUsernameException;
import it.csi.iride2.policy.exceptions.NoSuchApplicationException;
import it.csi.iride2.policy.exceptions.NoSuchUseCaseException;
import it.csi.iride2.policy.interfaces.PolicyEnforcerBaseService;

/*PROTECTED REGION ID(R1995720409) ENABLED START*/
/*PROTECTED REGION END*/

public class PEPProviderFacade implements PolicyEnforcerBaseService {

	public Actor[] findActorsForPersonaInApplication(Identita identita,
			Application app) throws UnrecoverableException, SystemException,
			InternalException, IdentitaNonAutenticaException,
			NoSuchApplicationException {
		Actor[] res = null;

		/*PROTECTED REGION ID(R789802439) ENABLED START*/
		/*PROTECTED REGION END*/

		return res;
	}

	public Actor[] findActorsForPersonaInUseCase(Identita identita,
			UseCase useCase) throws UnrecoverableException, SystemException,
			InternalException, IdentitaNonAutenticaException,
			NoSuchUseCaseException, NoSuchApplicationException {
		Actor[] res = null;

		/*PROTECTED REGION ID(R-389512800) ENABLED START*/
		/*PROTECTED REGION END*/

		return res;
	}

	public Ruolo[] findRuoliForPersonaInApplication(Identita identita,
			Application app) throws UnrecoverableException, SystemException,
			InternalException, IdentitaNonAutenticaException,
			NoSuchApplicationException {
		Ruolo[] res = null;

		/*PROTECTED REGION ID(R1687520656) ENABLED START*/
		/*PROTECTED REGION END*/

		return res;
	}

	public Ruolo[] findRuoliForPersonaInUseCase(Identita identita,
			UseCase useCase) throws UnrecoverableException, SystemException,
			InternalException, IdentitaNonAutenticaException,
			NoSuchUseCaseException, NoSuchApplicationException {
		Ruolo[] res = null;

		/*PROTECTED REGION ID(R412607977) ENABLED START*/
		/*PROTECTED REGION END*/

		return res;
	}

	public UseCase[] findUseCasesForPersonaInApplication(Identita identita,
			Application app) throws UnrecoverableException, SystemException,
			InternalException, IdentitaNonAutenticaException,
			NoSuchApplicationException {
		UseCase[] res = null;

		/*PROTECTED REGION ID(R1611720037) ENABLED START*/
		/*PROTECTED REGION END*/

		return res;
	}

	public String getInfoPersonaInUseCase(Identita identita, UseCase useCase)
			throws UnrecoverableException, SystemException, InternalException,
			IdentitaNonAutenticaException, NoSuchUseCaseException,
			NoSuchApplicationException {
		String res = null;

		/*PROTECTED REGION ID(R-1308303666) ENABLED START*/
		/*PROTECTED REGION END*/

		return res;
	}

	public String getInfoPersonaSchema(Ruolo ruolo)
			throws UnrecoverableException, SystemException, InternalException,
			BadRuoloException {
		String res = null;

		/*PROTECTED REGION ID(R-1356123489) ENABLED START*/
		/*PROTECTED REGION END*/

		return res;
	}

	public Identita identificaCertificato(byte[] arg0)
			throws UnrecoverableException, SystemException, InternalException,
			CertOutsideValidityException, CertRevokedException,
			IdProviderNotFoundException {
		Identita i = new Identita();

		/*PROTECTED REGION ID(R533629297) ENABLED START*/
		/*PROTECTED REGION END*/

		return i;
	}

	public Identita identificaUserPassword(String user, String password)
			throws UnrecoverableException, SystemException, InternalException,
			AuthException, IdProviderNotFoundException,
			MalformedUsernameException {

		Identita i = new Identita();

		/*PROTECTED REGION ID(R-624812120) ENABLED START*/
		/*PROTECTED REGION END*/

		return i;
	}

	public Identita identificaUserPasswordPIN(String user, String password,
			String pin) throws UnrecoverableException, SystemException,
			InternalException, AuthException, IdProviderNotFoundException,
			MalformedUsernameException {
		Identita i = new Identita();

		/*PROTECTED REGION ID(R-1971559773) ENABLED START*/
		/*PROTECTED REGION END*/

		return i;
	}

	public boolean isIdentitaAutentica(Identita identita)
			throws UnrecoverableException, SystemException, InternalException {
		boolean res = false;

		/*PROTECTED REGION ID(R-1202717428) ENABLED START*/
		/*PROTECTED REGION END*/

		return res;
	}

	public boolean isPersonaAutorizzataInUseCase(Identita identita,
			UseCase useCase) throws UnrecoverableException, SystemException,
			InternalException, IdentitaNonAutenticaException,
			NoSuchUseCaseException, NoSuchApplicationException {
		boolean res = false;

		/*PROTECTED REGION ID(R-1651042100) ENABLED START*/
		/*PROTECTED REGION END*/

		return res;
	}

	public boolean isPersonaInRuolo(Identita identita, Ruolo ruolo)
			throws UnrecoverableException, SystemException, InternalException,
			BadRuoloException, IdentitaNonAutenticaException {
		boolean res = false;

		/*PROTECTED REGION ID(R-1133191616) ENABLED START*/
		/*PROTECTED REGION END*/

		return res;
	}

	/*PROTECTED REGION ID(R453265878) ENABLED START*/
	/*PROTECTED REGION END*/

}
