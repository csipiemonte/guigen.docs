package it.csi.modlogext.modlogext.dto;

import java.util.Map;
import org.apache.log4j.*;
import it.csi.modlogext.modlogext.util.*;

/**
 * Superclasse astratta di tutti i DTO associati ai ContentPanel. 
 * I DTO associati ai content panel utilizzano la sessione applicativa per
 * la memorizzazione degli ApplicationData a scope 'session' o 'page'
 * @generated
 */
public abstract class BaseSessionAwareDTO implements java.io.Serializable {
	protected Map session;

	/**
	 * imposta un riferimento alla sessioen applicativa. Deve essere impostato in modo
	 * da condividere la sessione con la action
	 * @generated
	 */
	public void setSession(Map session) {
		this.session = session;
	}

	/**
	 * restituisce la sessione
	 * @generated
	 */
	public Map getSession() {
		return this.session;
	}

	/**  
	 * @generated
	 */
	protected static final Logger log = //NOSONAR  Reason:EIAS 
	Logger.getLogger(Constants.APPLICATION_CODE + ".dto"); //NOSONAR  Reason:EIAS

	/**
	 * dump di debug dello stato interno del DTO
	 * @generated
	 */
	public String dump() {
		StringBuffer sb = new StringBuffer();
		sb.append("" + getClass().getName() + "{\n");
		sb.append("\telenco fields:\n");
		java.beans.BeanInfo bi;
		try {
			bi = java.beans.Introspector.getBeanInfo(this.getClass());
			java.beans.PropertyDescriptor[] pds = bi.getPropertyDescriptors();
			for (int i = 0; i < pds.length; i++) {
				java.beans.PropertyDescriptor currPD = pds[i];
				java.lang.reflect.Method currReadMethod = currPD
						.getReadMethod();
				if (currReadMethod != null) {
					try {
						Object srcVal = currReadMethod.invoke(this,
								new Object[]{});
						sb.append("\t\t" + currPD.getName() + "=" + srcVal
								+ "\n");
					} catch (IllegalArgumentException e) {
						// questo caso non dovrebbe mai presentarsi
						sb.append("\t\t" + currPD.getName()
								+ "= <errore nell'accesso>" + "\n");
					} catch (IllegalAccessException e) {
						// questo caso non dovrebbe mai presentarsi
						sb.append("\t\t" + currPD.getName()
								+ "= <errore nell'accesso>" + "\n");
					} catch (java.lang.reflect.InvocationTargetException e) {
						// questo caso non dovrebbe mai presentarsi
						sb.append("\t\t" + currPD.getName()
								+ "= <errore nell'accesso>" + "\n");
					}
				}
			}
		} catch (java.beans.IntrospectionException e) {
			// questo caso non dovrebbe mai presentarsi
			sb.append("<errore nell accesso ai campi>");
		}

		sb.append("\t\t");

		sb.append("\tsessione:\n");

		sb.append("}\n");
		return sb.toString();
	}
}
