package it.csi.modlogext.modlogext.util;

/**
 * <p>Classe delle costanti applicative.</p>
 *
 * @author GuiGen
 */
public final class Constants {
	/**
	 * identificativo dell'applicativo.
	 */
	public static final String APPLICATION_CODE = "modlogext";

	/*PROTECTED REGION ID(R1581691183) ENABLED START*/
	// Add here your constants
	/*PROTECTED REGION END*/
}
