package it.csi.modlogext.modlogext.presentation.modlogext.action.mainmodello.states;

import it.csi.modlogext.modlogext.presentation.modlogext.action.ScreenStateCommand;

/**
 * Questa classe contiene le informazioni relative agli ScreenStates del ContentPanel cpHome
 */
public class CpHomeScreenStates {

}
