package it.csi.logesterna.logesterna.dto.logintns;

public class Login implements java.io.Serializable {

	/// Field [user]
	private java.lang.String _user = null;

	/**
	 * imposta il valore del campo [user]
	 * @param val
	 * @generated
	 */

	public void setUser(java.lang.String val) {
		_user = val;
	}

	/**
	 * legge il valore del campo [user]
	 * @generated
	 */
	public java.lang.String getUser() {
		return _user;
	}

	/// Field [pwd]
	private java.lang.String _pwd = null;

	/**
	 * imposta il valore del campo [pwd]
	 * @param val
	 * @generated
	 */

	public void setPwd(java.lang.String val) {
		_pwd = val;
	}

	/**
	 * legge il valore del campo [pwd]
	 * @generated
	 */
	public java.lang.String getPwd() {
		return _pwd;
	}

	// il serial version uid e' fisso in quanto la classe in oggetto e' serializzabile
	// solo per la clusterizzazione della sessione web e non viene scambiata con altre
	// componenti.
	private static final long serialVersionUID = 1L;

	/**
	 * Costruttore vuoto del DTO.
	 * @generated
	 */
	public Login() {
		super();

	}

	/**
	 * @generated
	 */
	public String toString() {
		/*PROTECTED REGION ID(R-945077737) ENABLED START*/
		/// inserire qui la logica desiderata per la rappresenatazione a stringa
		return super.toString();
		/*PROTECTED REGION END*/
	}
}
