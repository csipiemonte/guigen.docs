package it.csi.logesterna.logesterna.presentation.logesterna.action.loginmodello.states;

import it.csi.logesterna.logesterna.presentation.logesterna.action.ScreenStateCommand;

/**
 * Questa classe contiene le informazioni relative agli ScreenStates del ContentPanel cpLogin
 */
public class CpLoginScreenStates {

}
