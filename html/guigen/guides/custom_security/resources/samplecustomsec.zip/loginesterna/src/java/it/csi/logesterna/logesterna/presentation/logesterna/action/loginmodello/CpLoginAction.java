package it.csi.logesterna.logesterna.presentation.logesterna.action.loginmodello;

import java.util.*;

import java.lang.reflect.InvocationTargetException;
import java.beans.IntrospectionException;

import org.apache.struts2.interceptor.validation.SkipValidation;

import com.opensymphony.xwork2.ModelDriven;
import com.opensymphony.xwork2.Preparable;
import com.opensymphony.xwork2.validator.annotations.*;
import com.opensymphony.xwork2.conversion.annotations.*;
import com.opensymphony.xwork2.ActionContext;

import it.csi.logesterna.logesterna.dto.*;
import it.csi.logesterna.logesterna.dto.loginmodello.CpLoginModel;

import it.csi.logesterna.logesterna.presentation.logesterna.security.*;

import it.csi.logesterna.logesterna.business.*;

import it.csi.logesterna.logesterna.presentation.logesterna.action.*;

import it.csi.logesterna.logesterna.presentation.logesterna.action.loginmodello.states.CpLoginScreenStates;

import it.csi.logesterna.logesterna.presentation.logesterna.interceptor.MethodProtection;

/**
 * CpLoginAction Action Class.
 *
 * @author GuiGen
 */
@Validation()
@Conversion()
public class CpLoginAction extends BaseAction<CpLoginModel>
		implements
			Preparable,
			ModelDriven<CpLoginModel> {

	/**
	 * Il modello del content panel.
	 * Viene riempito a fornte delle interazioni con il browser e viene passato allo
	 * strato di business.
	 */
	private CpLoginModel model;

	/**
	 * Il modello del content panel.
	 * Viene riempito a fornte delle interazioni con il browser e viene passato allo
	 * strato di business.
	 */
	public CpLoginModel getModel() {
		return model;
	}

	/**
	 * Il modello del content panel.
	 * Viene riempito a fornte delle interazioni con il browser e viene passato allo
	 * strato di business.
	 */
	@VisitorFieldValidator(message = "", appendPrefix = false)
	public void setModel(CpLoginModel modello) {
		this.model = modello;
	}

	/**
	 * Il metodo setSession() viene ridefinito in modo che venga asosciato all'oggetto
	 * model.
	 * N.B: il model deve essere creato in precedenza, altrimenti l'impostazione non 
	 * e' possibile. 
	 * Per questo motivo esso viene creato in questo (se non già esistente).
	 */
	@Override
	public void setSession(Map session) {
		// implementazione standard di SessionAware
		super.setSession(session);
		// creo una nuova istanza di modello, se gia' non esiste 
		if (model == null) {
			model = new CpLoginModel();
		}
		// associo la sessione applicativa al modello, in modo che
		// possa implementare l'accesso agli application data
		// di scope session/same page
		model.setSession(session);
	}

	/**
	 * contiene le coppie <codice location, comando di jump corrispondente>
	 */
	private HashMap<String, JumpExtCommand> jumpExtCommands = new HashMap<String, JumpExtCommand>();

	/**
	 * contiene le coppie <codice location, comando di jump corrispondente>
	 */
	public HashMap<String, JumpExtCommand> getJumpExtCommands() {
		return jumpExtCommands;
	}

	/**
	 * contiene le coppie <codice location, comando di jump corrispondente>
	 */
	public void setJumpExtCommands(
			HashMap<String, JumpExtCommand> jumpExtCommands) {
		this.jumpExtCommands = jumpExtCommands;
	}

	/**
	 * nome del content panel
	 */
	private static final String CP_NAME = "cpLogin";

	private static final String URL_BACK_COMMAND = "/base/loginmodello/"
			+ CP_NAME;

	/**
	 * classe model associata al ContentPanel
	 */
	public Class modelClass() {
		return it.csi.logesterna.logesterna.dto.loginmodello.CpLoginModel.class;
	}

	/**
	 * I singoli eventi sui singoli widget sono gestiti dai metodi specifici   
	 * @return SUCCESS.
	 */
	@SkipValidation
	public String execute() throws CommandExecutionException {
		// esegue eventuali comandi di clear appdata
		ICommand clearCmd = (ICommand) session
				.get(PENDING_CLEAR_COMMAND_ATTRIBUTE);
		if (clearCmd != null) {
			// esegue la rimozione degli appdata a scope page, tramite l'apposito comando
			clearCmd.doCommand(this);
			// elimina il comando dalla sessione, in quanto ormai eseguito
			session.remove(PENDING_CLEAR_COMMAND_ATTRIBUTE);
		}

		// imposta il nome del content panel corrente
		setCurrentContentPanel(CP_NAME);
		return SUCCESS;
	}

	//////////////////////////////////////////////////////////////////////////////////
	/// metodi specifici per la gestione del singolo tipo di evento sul singolo widget
	/// contenuto nel contentPanel
	/// metodo: handle<nomeWidget>_<NOME_EVENTO>
	/// es: handletreeVoci_CLICKED
	//////////////////////////////////////////////////////////////////////////////////

	/**
	 * Gestione dell'evento CLICKED sul widget [btnokid]
	 */
	@MethodProtection(level = "REJECT_SAME")
	public String handleBtnokid_CLICKED() throws CommandExecutionException {

		return handleEventInternal("btnokid", "CLICKED");

	}

	/**
	 * Gestione della validazione
	 */
	public void validate() {
		/*PROTECTED REGION ID(R1577043587) ENABLED START*/
		/* Inserire la validazione */
		/*PROTECTED REGION END*/
	}

	protected Map<String, UISecConstraint> allVisibilityConstraints = null;
	protected Map<String, UISecConstraint> allOnOffConstraints = null;

	public void setCPCommandInitCpLogin(java.lang.Boolean value) {
		getSession().put("CPCommandInitCpLogin", value);
	}

	public java.lang.Boolean getCPCommandInitCpLogin() {
		return (java.lang.Boolean) (getSession().get("CPCommandInitCpLogin"));
	}

	/**
	 * Metodo di preparazione della schermata/action
	 */
	public void prepare() throws CommandExecutionException {
		super.prepare();

		// cancellazione eventuale degli errori di conversione non desiderati
		clearConversionErrorsIfSkipValidation();

		// caricamento struttura di constraints
		if (allVisibilityConstraints == null)
			allVisibilityConstraints = getPageVisibilityUIConstraints();
		if (allOnOffConstraints == null)
			allOnOffConstraints = getPageONOFFUIConstraints();

		ActionContext ctx = ActionContext.getContext();
		String methodName = ctx.getActionInvocation().getProxy().getMethod();

		boolean onRefreshEvent = true;

	}

	// ridefinizione dei metodi di verifica visibilita'/validazione
	// per supportare i security check

	/**
	 * Restituisce true se il widget e' abilitato.
	 * Il risultato e' condizionato da:
	 * - stato di default
	 * - stato comandato da OnOffCommand
	 * - stato comandato da ScreenStateCommand
	 * - security constraint
	 * @param cpName nome del content panel
	 * @param widgShortName nome del widget 
	 */
	public boolean isWidgetDisabled(String cpName, String widgShortName) {
		// recupero l'elenco del security constraint preparati in fase di
		// inizializzazione del pannello
		UISecConstraint ctr = allOnOffConstraints.get(widgShortName);
		if (ctr != null) {
			try {
				// se sono presenti dei constraint, li eseguo per conoscere lo stato
				// di abilitazione del widget
				return !ctr.verifyConstraint(session,
						UISecConstraint.ONOFF_CONSTRAINED_BEHAVIOR,
						getSpringSecurityHelper());
			} catch (BEException ex) {
				log.error("[CpLoginAction::isWidgetDisabled] errore durante verifica->disable");
				return true; // forzo la DISABILITAZIONE
			}
		} else {
			// se non sono presenti constraint vale l'implementazione di default
			return super.isWidgetDisabled(cpName, widgShortName);
		}
	}

	/**
	 * Restituisce true se il widget e' visibile.
	 * Il risultato e' condizionato da:
	 * - stato di default
	 * - stato comandato da VisibilityCommand
	 * - stato comandato da ScreenStateCommand
	 * - security constraint
	 * @param cpName nome del content panel
	 * @param widgShortName nome del widget 
	 */
	public boolean isWidgetVisible(String cpName, String widgShortName) {
		// recupero l'elenco del security constraint preparati in fase di
		// inizializzazione del pannello
		UISecConstraint ctr = allVisibilityConstraints.get(widgShortName);
		if (ctr != null) {
			try {
				// se sono presenti dei constraint, li eseguo per conoscere lo stato
				// di visibilita' del widget
				return ctr.verifyConstraint(session,
						UISecConstraint.VISIB_CONSTRAINED_BEHAVIOR,
						getSpringSecurityHelper());
			} catch (BEException ex) {
				log.error("[CpLoginAction::isWidgetVisible] errore durante verifica->hide");
				return false; // forzo l'invisibilita'
			}
		} else {
			// se non sono presenti constraint vale l'implementazione di default
			return super.isWidgetVisible(cpName, widgShortName);
		}
	}

	protected Map<String, UISecConstraint> getPageVisibilityUIConstraints() {
		Map<String, UISecConstraint> allConstraints = new HashMap<String, UISecConstraint>();

		// constraint fittizio per user
		UISecConstraint user_defaultVisib_ctr =

		new DummyUISecConstraint("cpLogin", "user",
				UISecConstraint.VISIB_CONSTRAINED_BEHAVIOR, true, true);

		//// ele nco di tutti i constraint dell'elemento 
		UISecConstraint[] user_constraints = new UISecConstraint[]{user_defaultVisib_ctr};
		//// constraint complessivo che racchiude ricorsivamente i singoli constraints
		UISecConstraint user_ctr = new ComplexUISecConstraint(user_constraints);
		//// inserisco il constraint complessivo nella mappa <nome elemento, constraints dell'elemento>
		allConstraints.put("user", user_ctr);

		// constraint fittizio per pwd
		UISecConstraint pwd_defaultVisib_ctr =

		new DummyUISecConstraint("cpLogin", "pwd",
				UISecConstraint.VISIB_CONSTRAINED_BEHAVIOR, true, true);

		//// ele nco di tutti i constraint dell'elemento 
		UISecConstraint[] pwd_constraints = new UISecConstraint[]{pwd_defaultVisib_ctr};
		//// constraint complessivo che racchiude ricorsivamente i singoli constraints
		UISecConstraint pwd_ctr = new ComplexUISecConstraint(pwd_constraints);
		//// inserisco il constraint complessivo nella mappa <nome elemento, constraints dell'elemento>
		allConstraints.put("pwd", pwd_ctr);

		// constraint fittizio per btnokid
		UISecConstraint btnokid_defaultVisib_ctr =

		new DummyUISecConstraint("cpLogin", "btnokid",
				UISecConstraint.VISIB_CONSTRAINED_BEHAVIOR, true, true);

		//// ele nco di tutti i constraint dell'elemento 
		UISecConstraint[] btnokid_constraints = new UISecConstraint[]{btnokid_defaultVisib_ctr};
		//// constraint complessivo che racchiude ricorsivamente i singoli constraints
		UISecConstraint btnokid_ctr = new ComplexUISecConstraint(
				btnokid_constraints);
		//// inserisco il constraint complessivo nella mappa <nome elemento, constraints dell'elemento>
		allConstraints.put("btnokid", btnokid_ctr);
		return allConstraints;
	}

	protected Map<String, UISecConstraint> getPageONOFFUIConstraints() {
		Map<String, UISecConstraint> allConstraints = new HashMap<String, UISecConstraint>();

		// constraint fittizio per user
		UISecConstraint user_defaultOnoff_ctr =

		new DummyUISecConstraint("cpLogin", "user",
				UISecConstraint.ONOFF_CONSTRAINED_BEHAVIOR, true, true);

		//// ele nco di tutti i constraint dell'elemento 
		UISecConstraint[] user_constraints = new UISecConstraint[]{user_defaultOnoff_ctr};
		//// constraint complessivo che racchiude ricorsivamente i singoli constraints
		UISecConstraint user_ctr = new ComplexUISecConstraint(user_constraints);
		//// inserisco il constraint complessivo nella mappa <nome elemento, constraints dell'elemento>
		allConstraints.put("user", user_ctr);

		// constraint fittizio per pwd
		UISecConstraint pwd_defaultOnoff_ctr =

		new DummyUISecConstraint("cpLogin", "pwd",
				UISecConstraint.ONOFF_CONSTRAINED_BEHAVIOR, true, true);

		//// ele nco di tutti i constraint dell'elemento 
		UISecConstraint[] pwd_constraints = new UISecConstraint[]{pwd_defaultOnoff_ctr};
		//// constraint complessivo che racchiude ricorsivamente i singoli constraints
		UISecConstraint pwd_ctr = new ComplexUISecConstraint(pwd_constraints);
		//// inserisco il constraint complessivo nella mappa <nome elemento, constraints dell'elemento>
		allConstraints.put("pwd", pwd_ctr);

		// constraint fittizio per btnokid
		UISecConstraint btnokid_defaultOnoff_ctr =

		new DummyUISecConstraint("cpLogin", "btnokid",
				UISecConstraint.ONOFF_CONSTRAINED_BEHAVIOR, true, true);

		//// ele nco di tutti i constraint dell'elemento 
		UISecConstraint[] btnokid_constraints = new UISecConstraint[]{btnokid_defaultOnoff_ctr};
		//// constraint complessivo che racchiude ricorsivamente i singoli constraints
		UISecConstraint btnokid_ctr = new ComplexUISecConstraint(
				btnokid_constraints);
		//// inserisco il constraint complessivo nella mappa <nome elemento, constraints dell'elemento>
		allConstraints.put("btnokid", btnokid_ctr);
		return allConstraints;
	}

	/**
	 * comandi da eseguire prima di ciascun evento
	 */
	protected void doBeforeEventCommand() throws CommandExecutionException {
		// comandi da eseguire prima dei comandi associati ad ogni evento

	}

	/**
	 * comandi da eseguire dopo ciascun evento
	 */
	protected void doAfterEventCommand() throws CommandExecutionException {
		// comandi da eseguire prima dei comandi associati ad ogni evento

	}

	/**  */
	protected void dumpModel(boolean pre) {
		log.debug("[CpLoginAction::dumpmodel] START");

		log.debug("[CpLoginAction::dumpmodel] #### DUMP del model della action "
				+ this.getClass()
				+ (pre ? " prima dell'azione" : " dopo l'azione"));
		log.debug("[CpLoginAction::dumpmodel] [a] campi pubblici del model");
		try {
			java.beans.BeanInfo bi = java.beans.Introspector.getBeanInfo(this
					.getClass());
			java.beans.PropertyDescriptor[] props = bi.getPropertyDescriptors();
			for (int i = 0; i < props.length; i++) {
				java.beans.PropertyDescriptor pd = props[i];
				java.lang.reflect.Method m = pd.getReadMethod();
				if (m != null) {
					Object pval = m.invoke(this, new Object[]{});
					log.debug("[CpLoginAction::dumpmodel] " + pd.getName()
							+ ":" + pval);
				}
			}
		} catch (IllegalAccessException e) {
			log.error("[CpLoginAction::dumpmodel] Errore nel dump" + e
					+ ", ignoro");
		} catch (InvocationTargetException e) {
			log.error("[CpLoginAction::dumpmodel] Errore nel dump" + e
					+ ", ignoro");
		} catch (IntrospectionException e) {
			log.error("[CpLoginAction::dumpmodel] Errore nel dump" + e
					+ ", ignoro");
		}
		log.debug("[CpLoginAction::dumpmodel] [b] stato dei widget");
		Object cpWidgetStatus = session.get("cpLogin");
		log.debug("[CpLoginAction::dumpmodel] " + cpWidgetStatus);
		log.debug("[CpLoginAction::dumpmodel] [c] sessione");
		log.debug("[CpLoginAction::dumpmodel] " + session);
	}

	static final String PENDING_CLEAR_COMMAND_ATTRIBUTE = "_pending_clear_command_";
	/**
	 *	Metodo per la rimozione dalla sessione degli application data a scope
	 *  SAME_PAGE. 
	 */
	public void clearPageScopedAppData(String targetContentPanelName) {
		// nothing to clear...
	}

	/**
	 * inizializza la struttura dei command da eseguire per ciascun event handler 
	 * di ciascun widget
	 */
	protected final ICommand initCommand(String sourceWidget, String eventType) {
		HashMap<String, HashMap<String, ICommand>> cmdsByWidget = new HashMap<String, HashMap<String, ICommand>>();

		// contiene i comandi del widget btnokid per ogni Ev.H.
		HashMap<String, ICommand> cmds4btnokidByEvh = new HashMap<String, ICommand>();

		cmds4btnokidByEvh.put("CLICKED", initCommandBtnokid_CLICKED());
		cmdsByWidget.put("btnokid", cmds4btnokidByEvh);

		ICommand ris = cmdsByWidget.get(sourceWidget).get(eventType);
		if (ris != null)
			return ris;
		else
			return new NOPCommand();
	}

	private ICommand initCommandBtnokid_CLICKED() {
		// ExecCommand begin
		String[] resultNames4confirmMethod = new String[]{"OK", "GO"};
		String[] appDataToStore4confirmMethod = new String[]{};

		ICommand[] actionsForResults4confirmMethod = new ICommand[2];
		/// NOP Command begin
		NOPCommand act_actions_clicked_btnokid_resokAction_0 = new NOPCommand();
		/// NOP Command end
		actionsForResults4confirmMethod[0] = act_actions_clicked_btnokid_resokAction_0;
		/// Jump Ext Command begin
		JumpExtCommand act_actions_clicked_btnokid_resgoAction_1 = new JumpExtCommand(
				"applicazioneurl", "", "urlGoToApp", false);
		jumpExtCommands.put("applicazioneurl",
				act_actions_clicked_btnokid_resgoAction_1);
		/// Jump Ext Command end
		actionsForResults4confirmMethod[1] = act_actions_clicked_btnokid_resgoAction_1;

		ExecCommand act_actions_clicked_btnokid_1 = new ExecCommand(
				resultNames4confirmMethod, actionsForResults4confirmMethod,
				"confirmMethod", appDataToStore4confirmMethod);
		// Exec Action end
		return act_actions_clicked_btnokid_1;
	}

	@SkipValidation
	public String handleChangeTab() {
		if (this.hasActionErrors() || this.hasFieldErrors() || this.hasErrors())
			return INPUT;
		else {
			session.put(getModel().getSelectedTabKey(), getModel()
					.getSelectedTabValue());
			return SUCCESS;
		}
	}

}
