package it.csi.logesterna.logesterna.presentation.logesterna.action;

/**
 * Implementazione del comando ClearAppDataCommand.
 */
public class ClearAppDataCommand implements ICommand {
	// il serial version uid e' fisso in quanto la classe in oggetto e' serializzabile
	// solo per poter essere inserita in sessione web e non viene scambiata con altre
	// componenti.
	private static final long serialVersionUID = 1L;

	private String[] _attributesToBeRemovedFromSession = null;

	/**
	 * @param nomi degli application data da cancellare
	 */
	public ClearAppDataCommand(String[] attributesToBeRemovedFromSession) {
		this._attributesToBeRemovedFromSession = attributesToBeRemovedFromSession;
	}

	/**
	 * Implementazione del comando clearAppdataCommand. 
	 * Il comando rimuove dalla sessione gli attributi corrispondenti
	 * agli application data elencati in attributesToBeRemovedFromSession
	 */
	public String doCommand(BaseAction strutsAction)
			throws CommandExecutionException {
		if (_attributesToBeRemovedFromSession != null
				&& _attributesToBeRemovedFromSession.length != 0) {
			for (int i = 0; i < _attributesToBeRemovedFromSession.length; i++) {
				strutsAction.getSession().remove(
						"appData" + _attributesToBeRemovedFromSession[i]);
			}
		}
		return null;
	}
};
