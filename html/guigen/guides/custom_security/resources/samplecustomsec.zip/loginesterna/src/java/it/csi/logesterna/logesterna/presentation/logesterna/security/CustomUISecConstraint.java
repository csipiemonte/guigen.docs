package it.csi.logesterna.logesterna.presentation.logesterna.security;

import java.util.Map;
import it.csi.logesterna.logesterna.business.*;

/**
 * Superclasse di tutti i custom security Constraints.
 * @param
 */
public class CustomUISecConstraint extends AbstractUISecConstraint {

	/**
	 * costruttore
	 * @param nomeContainer il nome del content panel che contiene il widget oggetto di constraint
	 * @param nomeWidget il nome del widget oggetto di constraint
	 * @param constraintedBehavior il comportamento vincolato (visibilita'/abilitazione)
	 * @param defaultState lo stato di default (relativamente al constrainedBehavior specificato) del widget oggetto di constraint
	 * @generated
	 */
	public CustomUISecConstraint(String nomeContainer, String nomeWidget,
			int constrainedBehavior, boolean defaultState) {
		super(nomeContainer, nomeWidget, constrainedBehavior, defaultState);
	}

	/**
	 * Implementazione da ridefinire nelle sottoclassi specifiche. Se non ridefinito restutuisce sempre true
	 * @generated
	 */
	@Override
	public boolean specificCheck(Map session, SecurityHelper sh)
			throws BEException {
		// viene sempre ridefinito
		return true;
	}

}
