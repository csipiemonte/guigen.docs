package it.csi.logesterna.logesterna.presentation.logesterna.action;

import java.util.Map;
import java.util.HashMap;

/**
 * Implementazione del comando OnOffCommand 
 */
public class OnOffCommand implements ICommand {

	// il serial version uid e' fisso in quanto la classe in oggetto e' serializzabile
	// solo per poter essere inserita in sessione web e non viene scambiata con altre
	// componenti.
	private static final long serialVersionUID = 1L;
	private static final String SESSION_MENU_ONOFF = "menuOnOffMap";

	String _containerName = null;
	String[] _targetsWidgets = null;
	String[] _targetsMenuElement = null;
	boolean _show = true;

	/**
	 * @param containerName il nome del content panel che contiene i widget da abilitare/disabilitare
	 * @param targetWidgets nomi dei widget da abilitare/disabilitare
	 * @param show se vale true i widget saranno abilitati, altrimenti saranno disabilitati
	 */
	public OnOffCommand(String containerName, String targetsWidgets[],
			boolean show) {
		_containerName = containerName;
		_targetsWidgets = targetsWidgets;
		_show = show;
	}

	/**
	 * @param containerName il nome del content panel che contiene i widget da abilitare/disabilitare
	 * @param targetWidgets nomi dei widget da abilitare/disabilitare
	 * @param targetsMenuElement nomi dei menu da abilitare/disabilitare
	 * @param show se vale true i widget/menu saranno abilitati, altrimenti saranno disabilitati
	 */
	public OnOffCommand(String containerName, String targetsWidgets[],
			String targetsMenuElement[], boolean show) {
		_containerName = containerName;
		_targetsWidgets = targetsWidgets;
		_targetsMenuElement = targetsMenuElement;
		_show = show;
	}

	/**
	 * esecuzione del comando OnOffCommand. Lo stato di abilitazione dei widget/menu e' contenuto in
	 * sessione.
	 */
	public String doCommand(BaseAction strutsAction)
			throws CommandExecutionException {
		if (_targetsWidgets != null) {
			Map<String, Boolean> cpWidgetsStatus = (Map<String, Boolean>) strutsAction.session
					.get(_containerName);
			if (cpWidgetsStatus == null) {
				cpWidgetsStatus = new HashMap<String, Boolean>();
				strutsAction.session.put(_containerName, cpWidgetsStatus);
			}
			for (int i = 0; i < _targetsWidgets.length; i++) {
				cpWidgetsStatus.put(_targetsWidgets[i] + "_enabled",
						Boolean.valueOf(_show));
			}
		}

		if (_targetsMenuElement != null) {
			Map<String, Boolean> menuOnOffMap = (Map<String, Boolean>) strutsAction.session
					.get(SESSION_MENU_ONOFF);
			if (menuOnOffMap == null) {
				menuOnOffMap = new HashMap<String, Boolean>();
				strutsAction.session.put(SESSION_MENU_ONOFF, menuOnOffMap);
			}
			for (int i = 0; i < _targetsMenuElement.length; i++) {
				menuOnOffMap.put(_targetsMenuElement[i] + "_enabled",
						Boolean.valueOf(_show));
			}
		}
		return null;
	}
}
