package it.csi.logesterna.logesterna.business;

import java.util.*;

import it.csi.logesterna.logesterna.dto.*;

import org.apache.log4j.*;
import it.csi.logesterna.logesterna.util.*;

/*PROTECTED REGION ID(R-1534196706) ENABLED START*/

/*PROTECTED REGION END*/

public class BackEndFacade {

	/**  */
	protected static final Logger log = //NOSONAR  Reason:EIAS 
	Logger.getLogger(Constants.APPLICATION_CODE + ".business"); //NOSONAR  Reason:EIAS

	//////////////////////////////////////////////////////////////////////////////
	/// Costanti identificative degli Application Data
	//////////////////////////////////////////////////////////////////////////////

	// ApplicationData: [currentUser, scope:USER_SESSION]
	public final static String APPDATA_CURRENTUSER_CODE = "appDatacurrentUser";

	// ApplicationData: [TreeStatus, scope:USER_SESSION]
	public final static String APPDATA_TREESTATUS_CODE = "appDataTreeStatus";

	// ApplicationData: [crumbs, scope:USER_SESSION]
	public final static String APPDATA_CRUMBS_CODE = "appDatacrumbs";

	// ApplicationData: [login, scope:USER_SESSION]
	public final static String APPDATA_LOGIN_CODE = "appDatalogin";

	// ApplicationData: [urlGoToApp, scope:USER_SESSION]
	public final static String APPDATA_URLGOTOAPP_CODE = "appDataurlGoToApp";

	//////////////////////////////////////////////////////////////////////////////
	/// Metodi associati alla U.I.
	/// - i metodi relativi a menu e azioni di inizializzazione sono direttamente 
	///   implementati in questa classe
	/// - i metodi relativi ai singoli content panel sono delegati nei rispettivi
	///   bean
	//////////////////////////////////////////////////////////////////////////////

	////////////////////////////////////////////////////////////////////////////////////

	/**
	 * richiama il metodo confirmMethod utilizzato in un ExecCommand
	 * del ContentPanel cpLogin
	 */
	public ExecResults confirmMethod(

	it.csi.logesterna.logesterna.dto.loginmodello.CpLoginModel theModel

	) throws BEException {
		// l'esecuzione viene delegata al bean corrispondente al ContentPanel cpLogin
		return getCPBECpLogin().confirmMethod(theModel);
	}

	//////////////////////////////////////////////////////////////////////////////
	/// Property relative ai bean spring associati agli specifici content panel
	//////////////////////////////////////////////////////////////////////////////

	/**
	 * riferimento al CPBE del content panel cpLogin
	 */
	private it.csi.logesterna.logesterna.business.loginmodello.CPBECpLogin _CPBECpLogin = null;

	/**
	 * riferimento al CPBE del content panel cpLogin
	 */
	public void setCPBECpLogin(
			it.csi.logesterna.logesterna.business.loginmodello.CPBECpLogin bean) {
		_CPBECpLogin = bean;
	}

	/**
	 * riferimento al CPBE del content panel cpLogin
	 */
	public it.csi.logesterna.logesterna.business.loginmodello.CPBECpLogin getCPBECpLogin() {
		return _CPBECpLogin;
	}

	//////////////////////////////////////////////////////////////////////////////
	/// Property aggiuntive del bean
	//////////////////////////////////////////////////////////////////////////////
	/*PROTECTED REGION ID(R-1264235389) ENABLED START*/
	//// inserire qui le property che si vogliono iniettare in questo bean (es. dao, proxy di pd, ...) 
	/*PROTECTED REGION END*/
}
