package it.csi.logesterna.logesterna.dto.loginmodello;

import java.util.*;
import it.csi.logesterna.logesterna.dto.*;
import it.csi.logesterna.logesterna.dto.common.*;
import it.csi.logesterna.logesterna.dto.logintns.*;

import com.opensymphony.xwork2.conversion.annotations.*;
import com.opensymphony.xwork2.validator.annotations.*;

/**
 * Questo DTO incapsula tutto il contenuto informativo necessario all'esecuzione della
 * logica di business associata alla Schermata [cpLogin]
 */
@Validation
public class CpLoginModel extends BaseSessionAwareDTO {

	// il serial version uid e' fisso in quanto la classe in oggetto e' serializzabile
	// solo per la clusterizzazione della sessione web e non viene scambiata con altre
	// componenti.
	private static final long serialVersionUID = 1L;

	////////////////////////////////////////////////////////////////////
	/// application data
	////////////////////////////////////////////////////////////////////

	/**
	 * imposta il valore dell' ApplicationData 'appDatalogin'
	 * @param value
	 * @generated
	 */

	public void setAppDatalogin(
			it.csi.logesterna.logesterna.dto.logintns.Login value) {
		getSession().put("appDatalogin", value);
	}

	/**
	 * legge il valore dell' ApplicationData 'appDatalogin'
	 * @generated
	 */
	public it.csi.logesterna.logesterna.dto.logintns.Login getAppDatalogin() {
		return (it.csi.logesterna.logesterna.dto.logintns.Login) (getSession()
				.get("appDatalogin"));
	}

	/**
	 * imposta il valore dell' ApplicationData 'appDataurlGoToApp'
	 * @param value
	 * @generated
	 */

	public void setAppDataurlGoToApp(java.lang.String value) {
		getSession().put("appDataurlGoToApp", value);
	}

	/**
	 * legge il valore dell' ApplicationData 'appDataurlGoToApp'
	 * @generated
	 */
	public java.lang.String getAppDataurlGoToApp() {
		return (java.lang.String) (getSession().get("appDataurlGoToApp"));
	}

	////////////////////////////////////////////////////////////////////
	/// campi per widget semplici
	////////////////////////////////////////////////////////////////////

	////////////////////////////////////////////////////////////////////
	/// ulteriori campi comuni 
	////////////////////////////////////////////////////////////////////

	/////////////////////////////////////////
	/// property comuni a tutte le action
	/////////////////////////////////////////

	/// parametri per cambio TAB

	private String selectedTabKey;

	public void setSelectedTabKey(String value) {
		selectedTabKey = value;
	}

	public String getSelectedTabKey() {
		return selectedTabKey;
	}

	private String selectedTabValue;

	public void setSelectedTabValue(String value) {
		selectedTabValue = value;
	}

	public String getSelectedTabValue() {
		return selectedTabValue;
	}

}
