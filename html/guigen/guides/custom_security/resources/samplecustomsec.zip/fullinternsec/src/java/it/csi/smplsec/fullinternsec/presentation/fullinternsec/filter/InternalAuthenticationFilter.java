package it.csi.smplsec.fullinternsec.presentation.fullinternsec.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/**
 *
 * @author CSIPiemonte
 */
public class InternalAuthenticationFilter implements Filter {

	public final static String TICKET = "myTicketSource";
	public static final String SECURITY_SESSION_MARKER = "iride2_id";

	public static String loginPage;

	public void doFilter(ServletRequest req, ServletResponse resp,
			FilterChain fchn) throws IOException, ServletException {

		HttpServletRequest hreq = (HttpServletRequest) req;
		HttpServletResponse hresp = (HttpServletResponse) resp;

		if (hreq.getRequestURI().indexOf(loginPage) > -1) {
			fchn.doFilter(req, resp);
			return;
		}

		Object marker = getMarker(hreq);

		if (marker == null) {
			Object ticket = getTicket(hreq);

			if (ticket != null) {
				fchn.doFilter(req, resp);
			} else
				hresp.sendRedirect(loginPage);
		} else
			fchn.doFilter(req, resp);

	}

	public void destroy() {

	}

	private Object getMarker(HttpServletRequest hreq) {
		return hreq.getSession().getAttribute(SECURITY_SESSION_MARKER);
	}

	private Object getTicket(HttpServletRequest hreq) {
		HttpSession session = hreq.getSession();
		return session != null ? (String) session.getAttribute(TICKET) : null;
	}

	public void init(FilterConfig config) throws ServletException {
		loginPage = config.getInitParameter("loginPage");
	}
}
