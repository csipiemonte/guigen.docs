package it.csi.smplsec.fullinternsec.util;
import it.csi.csi.porte.AbstractPortaDelegata;
import it.csi.csi.porte.InfoPortaDelegata;
import it.csi.csi.util.DatiMessaggio;
import it.csi.csi.util.Param;
import it.csi.csi.util.log.Categories;
import it.csi.csi.wrapper.AbstractAdapter;
import it.csi.csi.wrapper.CSIException;
import it.csi.csi.wrapper.SystemException;
import it.csi.csi.wrapper.UnrecoverableException;
import it.csi.csi.wrapper.UserException;
import it.csi.smplsec.fullinternsec.presentation.fullinternsec.security.pepprovider.*;

import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class SpringPD extends AbstractPortaDelegata {

	protected Object fakeImplObj = null;

	public SpringPD() {
	}

	public SpringPD(InfoPortaDelegata info) {
		setInfo(info);
	}

	public void setInfo(InfoPortaDelegata info) {
		super.setInfo(info);

		ClassPathResource cpr = new ClassPathResource(
				"/WEB-INF/applicationContext.xml");
		BeanFactory ctx = new XmlBeanFactory(cpr);
		fakeImplObj = (PEPProviderFacade) ctx
				.getBean("pepProviderFacadeBeanId");
	}

	public Param invokeSynch(String methodName, Param[] param)
			throws it.csi.csi.wrapper.CSIException {
		Categories.getLogger(null, Categories.PORTA_DELEGATA).debug(
				"invocazione metodo fittizio sincrono " + methodName);
		try {
			// ottiene un'istanza di service object
			Object srv = fakeImplObj;
			//
			Method method = AbstractAdapter.locateMethodInInterfaces(srv,
					methodName, param);
			if (method != null) {
				Object args[] = new Object[param.length];
				for (int i = 0; i < param.length; i++) {
					args[i] = param[i].getValue();
				}
				try {
					Object retval = method.invoke(srv, args);
					//Param retPar = new Param("retval",(retval == null ? Object.class : retval.getClass()),retval,null);
					Param retPar = AbstractAdapter.buildRetVal(retval,
							method.getReturnType());
					return retPar;
				} catch (InvocationTargetException ite) {
					// arrivo qui se ci sono errori sul server RMI
					Throwable ex = ite.getTargetException();
					if (ex instanceof UserException
							|| ex instanceof SystemException
							|| ex instanceof UnrecoverableException)
						throw (CSIException) ex;
					else {
						Categories.getLogger(getAppContextName(),
								Categories.PA_WRAPPER_ADAPTER).error(
								"Errore imprevisto sollevato dal servizio:"
										+ ite.getTargetException());
						ite.printStackTrace();
						throw new UnrecoverableException(
								"Errore imprevisto sollevato dal servizio:",
								ite.getTargetException());
					}
				} catch (IllegalAccessException iae) {
					// arrivo qui se ci sono problemi nel chiamare il servizio
					Categories.getLogger(getAppContextName(),
							Categories.PA_WRAPPER_ADAPTER).error(
							"Errore imprevisto nell'invocazione del servizio:"
									+ iae);
					iae.printStackTrace();
					throw new UnrecoverableException(
							"Errore imprevisto nell'invocazione del servizio",
							iae);
				}
			} else {
				/// errore metodo non trovato
				Categories.getLogger(getAppContextName(),
						Categories.PA_WRAPPER_ADAPTER).error(
						"Metodo " + methodName + " non trovato nel servizio");
				throw new UnrecoverableException("Metodo " + methodName
						+ " non trovato nel servizio");
			}
		} catch (CSIException locex) {
			throw locex;
		}
	}

	public String sendEvent(String methodName, Param[] param,
			DatiMessaggio datiMsg) throws it.csi.csi.wrapper.CSIException {
		Categories.getLogger(null, Categories.PORTA_DELEGATA).debug(
				"invocazione metodo fittizio asincrono P2P " + methodName);
		Param[] allParams = new Param[param.length + 1];
		for (int i = 0; i < param.length; i++)
			allParams[i] = param[i];
		allParams[allParams.length - 1] = new Param("datiMsg",
				DatiMessaggio.class, false, datiMsg, "");
		return (String) (this.invokeSynch(methodName, allParams).getValue());
	}
	public String invokeAsynch(String methodName, Param[] param,
			DatiMessaggio datiMsg) throws it.csi.csi.wrapper.CSIException {
		Categories.getLogger(null, Categories.PORTA_DELEGATA).debug(
				"invocazione metodo fittizio asincrono PUB&SUB " + methodName);
		Param[] allParams = new Param[param.length + 1];
		for (int i = 0; i < param.length; i++)
			allParams[i] = param[i];
		allParams[allParams.length - 1] = new Param("datiMsg",
				DatiMessaggio.class, false, datiMsg, "");
		return (String) (this.invokeSynch(methodName, allParams).getValue());
	}

	/**
	 * Questo metodo ricerca tramite introspection l'oggetto Method corrispondente al nome
	 * (methodName) e ai parametri (param[]). Poichè RMI/EJB non riescono a serializzare oggetti
	 * Class che rappresentano tipi semplici a causa di un baco della JVM di SUN (Bug Id  4171142),
	 * nell'oggetto param, in caso di tipo semplice c'è il campo "simple" = true. A differenza dai
	 * metadata CSI la reflection riesce a trovare correttamente i metodi che prendono tipi semplici,
	 * passando al metodo getMethod() come classi i tipi semplici. Per far ciò occorre ritrasformare
	 * eventuali coppie <wrapper di tipo semplice, simple=true> nel corrispondente tipo semplice.
	 * Poi l'introspection farà il resto.
	 * @param srv
	 * @param methodName
	 * @param params
	 * @return il metodo che corrisponde alla signature
	 */
	public static Method locateMethodInInterfaces(Object srv,
			String methodName, Param[] params) {
		Class wrapperClass = srv.getClass();
		Class[] interfaces = wrapperClass.getInterfaces();
		Class[] parClasses = new Class[params.length];
		for (int i = 0; i < params.length; i++) {
			// devo ripristinare i tipi corretti nei casi simple type e array di simple type
			if (params[i].isSimple()) {
				if (!params[i].getType().isArray())
					parClasses[i] = Param.getWrappedType(params[i].getType());
				else {
					Object dummyArrInst = Array.newInstance(Param
							.getWrappedType(params[i].getType()
									.getComponentType()), 1);
					parClasses[i] = dummyArrInst.getClass();
				}
			} else
				parClasses[i] = params[i].getType();
		}
		// primo ciclo: su tutte le interfacce faccio una ricerca diretta con i metodi
		// della reflection
		for (int i = 0; i < interfaces.length; i++) {
			Class currInt = interfaces[i];
			try {
				Method m = currInt.getMethod(methodName, parClasses);
				if (m != null) // precauzione ma non dovrebbe mai essere nullo (eccezione!!)
					return m;
			} catch (NoSuchMethodException nsme) {
				// non era l'interfaccia giusta.
				continue;
			}
		}
		/// secondo ciclo: se non l'ho trovato prima provo a cercare più a fondo
		/// utilizzando tipi semplici dove ci sono wrapper di tipi semplici, per
		/// ovviare al problema del Proxy dinamico che non permette (?) di sapere se
		/// il tipo di un parametro attuale è primitivo o davvero un wrapper.
		for (int ii = 0; ii < interfaces.length; ii++) {
			Class currInt = interfaces[ii];
			try {
				// trasformo in primitivi tutti i tipi wrapper
				for (int j = 0; j < parClasses.length; j++) {
					Class currClass = parClasses[j];
					//if (currClass.isPrimitive()){
					if (currClass.equals(Integer.class))
						parClasses[j] = Integer.TYPE;
					else if (currClass.equals(Long.class))
						parClasses[j] = Long.TYPE;
					else if (currClass.equals(Float.class))
						parClasses[j] = Float.TYPE;
					else if (currClass.equals(Double.class))
						parClasses[j] = Double.TYPE;
					else if (currClass.equals(Byte.class))
						parClasses[j] = Byte.TYPE;
					else if (currClass.equals(Boolean.class))
						parClasses[j] = Boolean.TYPE;
					// se no lascia tutto com'è
					//}
				}
				Method m = currInt.getMethod(methodName, parClasses);
				if (m != null) // precauzione ma non dovrebbe mai essere nullo (eccezione!!)
					return m;
			} catch (NoSuchMethodException nsme) {
				// non era l'interfaccia giusta.
				continue;
			}
		}
		return null;
	}

	/**
	 * Costruisce un oggetto Param da ritornare alla PD chiamante, tenendo conto del tipo
	 * dichiarato nell'interfaccia. Serve per gestire correttamente le coppie <tipo, simple>
	 * anche nel caso di ritorno.
	 * @param value
	 * @param declaredRetType
	 * @return l'oggetto Param che contiene il valore di ritorno
	 */

	public static Param buildRetVal(Object value, Class<?> declaredRetType) {
		Class actType = declaredRetType;
		Param p = null;
		// se il value è null il tipo lo metto = Object (non usato)
		if (value == null) {
			actType = Object.class;
			p = new Param("retval", actType, value, "");
			return p;
		} else {
			if (actType.isArray() && actType.getComponentType().isPrimitive()) {
				Object dummyArr = Array.newInstance(
						Param.getPrimitiveWrapper(actType.getComponentType()),
						1);
				p = new Param("retval", dummyArr.getClass(), true, value, "");
				return p;
			}
			// serve per mettere il tipo più specifico possibile
			else if (declaredRetType.isAssignableFrom(value.getClass())) {
				actType = value.getClass();
				p = new Param("retval", actType, value, "");
				return p;
			} else {
				p = new Param("retval", actType, value, "");
				return p;
			}
		}
	}
	public String getAppContextName() {
		return null;
	}
}
