package it.csi.smplsec.fullinternsec.presentation.fullinternsec.action;

/**
 * Implementazione del comando RefreshViewCommand.
 */
public class RefreshViewCommand implements ICommand {

	// il serial version uid e' fisso in quanto la classe in oggetto e' serializzabile
	// solo per poter essere inserita in sessione web e non viene scambiata con altre
	// componenti.
	private static final long serialVersionUID = 1L;

	String _currentPanelName = null;
	String[] _targetPanels = null;
	String[] _targetWidgets = null;

	/**
	 * @param currentPanelName il nome del ContentPanel su cui deve essere effettuato il refresh
	 * @param targetPanelNames l'elenco dei nomi dei pannelli da rinfrescare
	 * @param targetWidgetNames l'elenco dei nomi dei widget da rinfrescare
	 */
	public RefreshViewCommand(String currentPanelName,
			String[] targetPanelNames, String[] targetWidgetNames) {
		_currentPanelName = currentPanelName;
		_targetPanels = targetPanelNames;
		_targetWidgets = targetWidgetNames;
	}

	/**
	 * Nell'implementazione struts l'esecuzione di questo comando e' completamente a carico dello 
	 * strato javascript.
	 * Pertanto l'unico effetto di questo comando e' quello di comandare al workflow di struts la
	 * restituizione della pagina completa. La parte client ritagliera' le parti a seconda di 
	 * quali pannelli target sono stati modellati. 
	 */
	public String doCommand(BaseAction strutsAction)
			throws CommandExecutionException {
		return null;
	}
};
