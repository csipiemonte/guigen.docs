package it.csi.smplsec.fullinternsec.presentation.fullinternsec.security;

import java.util.Map;
import it.csi.smplsec.fullinternsec.business.*;

/**
 * Security constraint composito. La composizione avviene in OR. 
 * @generated
 */
public class ComplexUISecConstraint implements UISecConstraint {

	/**
	 * i constraint da verificare
	 * @generated
	 */
	protected UISecConstraint[] constraints = null;

	/**
	 * costruttore
	 * @param constraints i constraint da verificare
	 * @generated
	 */
	public ComplexUISecConstraint(UISecConstraint[] constraints) {
		this.constraints = constraints;
	}

	/**
	 * Verifica se almeno uno dei constraints &egrave; soddisfatto.
	 * @param session la sessioen applicativa
	 * @param checkedBehavior il comportamento oggetto di vincolo (visibilita'/abilitazione)
	 * @param sh il security helper
	 * @generated
	 */
	public boolean verifyConstraint(Map session, int checkedBehavior,
			SecurityHelper sh) throws BEException {
		if (constraints != null && constraints.length > 0) {
			boolean verified = false;
			for (int i = 0; i < constraints.length && !verified; i++) {
				UISecConstraint currCtr = constraints[i];
				verified |= currCtr.verifyConstraint(session, checkedBehavior,
						sh);
			}
			return verified;
		} else
			return true;
	}

}
