package it.csi.smplsec.fullinternsec.util;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/*PROTECTED REGION ID(R53866960) ENABLED START*/
/*PROTECTED REGION END*/

public class SessionListener implements HttpSessionListener {

	/*PROTECTED REGION ID(R-1638345655) ENABLED START*/
	/*PROTECTED REGION END*/

	public SessionListener() {
		/*PROTECTED REGION ID(R-1526106981) ENABLED START*/
		/*PROTECTED REGION END*/
	}

	public void sessionCreated(HttpSessionEvent se) {
		/*PROTECTED REGION ID(R1034942020) ENABLED START*/
		/*PROTECTED REGION END*/
	}

	public void sessionDestroyed(HttpSessionEvent se) {
		/*PROTECTED REGION ID(R-464738699) ENABLED START*/
		/*PROTECTED REGION END*/
	}
}
