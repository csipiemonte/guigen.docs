package it.csi.smplsec.fullinternsec.dto.common;

public class UserInfo implements java.io.Serializable {

	/// Field [nome]
	private java.lang.String _nome = null;

	/**
	 * imposta il valore del campo [nome]
	 * @param val
	 * @generated
	 */

	public void setNome(java.lang.String val) {
		_nome = val;
	}

	/**
	 * legge il valore del campo [nome]
	 * @generated
	 */
	public java.lang.String getNome() {
		return _nome;
	}

	/// Field [cognome]
	private java.lang.String _cognome = null;

	/**
	 * imposta il valore del campo [cognome]
	 * @param val
	 * @generated
	 */

	public void setCognome(java.lang.String val) {
		_cognome = val;
	}

	/**
	 * legge il valore del campo [cognome]
	 * @generated
	 */
	public java.lang.String getCognome() {
		return _cognome;
	}

	/// Field [codFisc]
	private java.lang.String _codFisc = null;

	/**
	 * imposta il valore del campo [codFisc]
	 * @param val
	 * @generated
	 */

	public void setCodFisc(java.lang.String val) {
		_codFisc = val;
	}

	/**
	 * legge il valore del campo [codFisc]
	 * @generated
	 */
	public java.lang.String getCodFisc() {
		return _codFisc;
	}

	/// Field [ente]
	private java.lang.String _ente = null;

	/**
	 * imposta il valore del campo [ente]
	 * @param val
	 * @generated
	 */

	public void setEnte(java.lang.String val) {
		_ente = val;
	}

	/**
	 * legge il valore del campo [ente]
	 * @generated
	 */
	public java.lang.String getEnte() {
		return _ente;
	}

	/// Field [ruolo]
	private java.lang.String _ruolo = null;

	/**
	 * imposta il valore del campo [ruolo]
	 * @param val
	 * @generated
	 */

	public void setRuolo(java.lang.String val) {
		_ruolo = val;
	}

	/**
	 * legge il valore del campo [ruolo]
	 * @generated
	 */
	public java.lang.String getRuolo() {
		return _ruolo;
	}

	/// Field [idIride]
	private java.lang.String _idIride = null;

	/**
	 * imposta il valore del campo [idIride]
	 * @param val
	 * @generated
	 */

	public void setIdIride(java.lang.String val) {
		_idIride = val;
	}

	/**
	 * legge il valore del campo [idIride]
	 * @generated
	 */
	public java.lang.String getIdIride() {
		return _idIride;
	}

	/// Field [codRuolo]
	private java.lang.String _codRuolo = null;

	/**
	 * imposta il valore del campo [codRuolo]
	 * @param val
	 * @generated
	 */

	public void setCodRuolo(java.lang.String val) {
		_codRuolo = val;
	}

	/**
	 * legge il valore del campo [codRuolo]
	 * @generated
	 */
	public java.lang.String getCodRuolo() {
		return _codRuolo;
	}

	// il serial version uid e' fisso in quanto la classe in oggetto e' serializzabile
	// solo per la clusterizzazione della sessione web e non viene scambiata con altre
	// componenti.
	private static final long serialVersionUID = 1L;

	/**
	 * Costruttore vuoto del DTO.
	 * @generated
	 */
	public UserInfo() {
		super();

	}

	/**
	 * @generated
	 */
	public String toString() {
		/*PROTECTED REGION ID(R-579808706) ENABLED START*/
		/// inserire qui la logica desiderata per la rappresenatazione a stringa
		return super.toString();
		/*PROTECTED REGION END*/
	}
}
