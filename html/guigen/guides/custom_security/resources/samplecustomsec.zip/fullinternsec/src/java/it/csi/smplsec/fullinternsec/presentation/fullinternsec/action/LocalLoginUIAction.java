package it.csi.smplsec.fullinternsec.presentation.fullinternsec.action;

import it.csi.iride2.policy.entity.Identita;

import it.csi.csi.wrapper.SystemException;
import it.csi.csi.wrapper.UnrecoverableException;
import it.csi.iride2.policy.exceptions.AuthException;
import it.csi.iride2.policy.exceptions.IdProviderNotFoundException;
import it.csi.iride2.policy.exceptions.InternalException;
import it.csi.iride2.policy.exceptions.MalformedUsernameException;
import it.csi.smplsec.fullinternsec.business.BEException;
import it.csi.smplsec.fullinternsec.dto.*;
/*PROTECTED REGION ID(R526059915) ENABLED START*/
/*PROTECTED REGION END*/

public class LocalLoginUIAction extends BaseAction {
	public final static String TICKET = "myTicketSource";

	public String execute() throws Exception {

		return SUCCESS;
	}

	public String validaLogin() throws BEException {
		if (isNotEmpty(getUsername()) && isNotEmpty(getPassword())) {

			Identita i;
			try {
				i = getSpringSecurityHelper().identificaUserPassword(
						getUsername(), getPassword());

				getSession().put(TICKET, i.toString());
			} catch (BEException e) {
				log.error(
						"[LocalLoginUIAction::validaLogin] Errore validazione Login:"
								+ e, e);
				throw new BEException("Errore validazione Login:" + e, e);
			} catch (InternalException e) {
				log.error(
						"[LocalLoginUIAction::validaLogin] InternalException Login:"
								+ e, e);
				throw new BEException("Errore validazione Login:" + e, e);
			} catch (AuthException e) {
				log.error(
						"[LocalLoginUIAction::validaLogin] AuthException Login:"
								+ e, e);
				return "autorizzazioneFallita";
			} catch (IdProviderNotFoundException e) {
				log.error(
						"[LocalLoginUIAction::validaLogin] IdProviderNotFoundException Login:"
								+ e, e);
				return "autorizzazioneFallita";
			} catch (MalformedUsernameException e) {
				log.error(
						"[LocalLoginUIAction::validaLogin] MalformedUsernameException Login:"
								+ e, e);
				return "autorizzazioneFallita";
			} catch (UnrecoverableException e) {
				log.error(
						"[LocalLoginUIAction::validaLogin] UnrecoverableException Login:"
								+ e, e);
				throw new BEException("Errore validazione Login:" + e, e);
			} catch (SystemException e) {
				log.error(
						"[LocalLoginUIAction::validaLogin] SystemException Login:"
								+ e, e);
				throw new BEException("Errore validazione Login:" + e, e);
			}
			return "GO_TO_HomePage";
		}
		return "autorizzazioneFallita";
	}

	private boolean isNotEmpty(String value) {
		return value != null && !value.equalsIgnoreCase("");

	}

	private String username;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	private String password;

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Class modelClass() {
		// TODO Auto-generated method stub
		return null;
	}

	public void clearPageScopedAppData(String targetContentPanelName) {
		// TODO Auto-generated method stub

	}

	///////////////

	@Override
	public BaseSessionAwareDTO getModel() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setModel(BaseSessionAwareDTO t) {
		// TODO Auto-generated method stub

	}

	@Override
	protected void dumpModel(boolean pre) {
		// TODO Auto-generated method stub

	}

	@Override
	protected void doBeforeEventCommand() throws CommandExecutionException {
		// TODO Auto-generated method stub

	}

	@Override
	protected void doAfterEventCommand() throws CommandExecutionException {
		// TODO Auto-generated method stub

	}

	@Override
	protected ICommand initCommand(String widgName, String eventName) {
		// TODO Auto-generated method stub
		return null;
	}

}
