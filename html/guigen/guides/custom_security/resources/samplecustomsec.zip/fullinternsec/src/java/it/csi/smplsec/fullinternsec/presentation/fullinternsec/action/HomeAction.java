package it.csi.smplsec.fullinternsec.presentation.fullinternsec.action;

import java.util.*;

import org.apache.struts2.interceptor.validation.SkipValidation;

import com.opensymphony.xwork2.ModelDriven;
import com.opensymphony.xwork2.validator.annotations.*;

import it.csi.smplsec.fullinternsec.dto.*;

import it.csi.smplsec.fullinternsec.business.*;

/**
 * HomeAction Action Class.
 *
 * @author GuiGen
 */
@Validation()
public class HomeAction extends BaseAction<GlobalHomeModel>
		implements
			ModelDriven<GlobalHomeModel> {

	private GlobalHomeModel model;

	public GlobalHomeModel getModel() {
		return model;
	}

	public void setModel(GlobalHomeModel modello) {
		this.model = modello;
	}

	@Override
	public void setSession(Map session) {
		// TODO Auto-generated method stub
		super.setSession(session);
		if (model == null) {
			model = new GlobalHomeModel();
		}
		model.setSession(session);
	}

	private HashMap<String, JumpExtCommand> jumpExtCommands = new HashMap<String, JumpExtCommand>();

	public HashMap<String, JumpExtCommand> getJumpExtCommands() {
		return jumpExtCommands;
	}

	public void setJumpExtCommands(
			HashMap<String, JumpExtCommand> jumpExtCommands) {
		this.jumpExtCommands = jumpExtCommands;
	}

	/**
	 * classe model associata
	 */
	public Class modelClass() {

		return java.lang.Object.class;

	}

	/**
	 * Gestione della validazione
	 */
	public void validate() {
		/*PROTECTED REGION ID(R103397888) ENABLED START*/
		/* Inserire la validazione */
		/*PROTECTED REGION END*/
	}

	protected void dumpModel(boolean pre) {
		// metodo intenzionalmente vuoto
	}

	protected ICommand initCommand(String widgName, String eventName) {
		// metodo intenzionalmente vuoto
		return null;
	}

	protected void doBeforeEventCommand() {
		// la home action e' globale: non sono previsti before/after event commands
	}

	protected void doAfterEventCommand() {
		// la home action e' globale: non sono previsti before/after event commands
	}

	/**
	 *	Metodo per la rimozione dalla sessione degli application data a scope
	 *  SAME_PAGE. 
	 */
	public void clearPageScopedAppData(String targetContentPanelName) {
		// TODO: nel caso dell'on-init command non si ha ancora un 
		// "content panel corrente" -> NOP
	}

}
