package it.csi.smplsec.fullinternsec.presentation.uiutils;

/**
 * Utilizzata per le funzioni di filtro del widget della cartuccia "fat"
 * @generated
 */

public class DataFilter {

	/**
	 * type
	 */
	private String type;

	/**
	 * value
	 */
	private String value;

	/**
	 * comparison
	 */
	private String comparison;

	/**
	 * type
	 */
	public String getType() {
		return type;
	}

	/**
	 * type
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * value
	 */
	public void setValue(String value) {
		this.value = value;
	}
	/**
	 * comparison
	 */
	public String getComparison() {
		return comparison;
	}

	/**
	 * comparison
	 */
	public void setComparison(String comparison) {
		this.comparison = comparison;
	}

}
