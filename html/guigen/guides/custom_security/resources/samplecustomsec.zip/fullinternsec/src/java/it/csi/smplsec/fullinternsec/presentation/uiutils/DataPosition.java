package it.csi.smplsec.fullinternsec.presentation.uiutils;

/**
 * @generated
 */
public class DataPosition {

	//***id del record nella collection
	private String id;

	//***posizione originale del record nella collection
	private int position;

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getPosition() {
		return position;
	}
	public void setPosition(int position) {
		this.position = position;
	}

}
