package it.csi.smplsec.fullinternsec.presentation.fullinternsec.action.main.states;

import it.csi.smplsec.fullinternsec.presentation.fullinternsec.action.ScreenStateCommand;

/**
 * Questa classe contiene le informazioni relative agli ScreenStates del ContentPanel cpHome
 */
public class CpHomeScreenStates {

}
