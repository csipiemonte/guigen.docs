package it.csi.smplsec.fullinternsec.presentation.fullinternsec.action.main;

import java.util.*;

import java.lang.reflect.InvocationTargetException;
import java.beans.IntrospectionException;

import org.apache.struts2.interceptor.validation.SkipValidation;

import com.opensymphony.xwork2.ModelDriven;
import com.opensymphony.xwork2.Preparable;
import com.opensymphony.xwork2.validator.annotations.*;
import com.opensymphony.xwork2.conversion.annotations.*;
import com.opensymphony.xwork2.ActionContext;

import it.csi.smplsec.fullinternsec.dto.*;
import it.csi.smplsec.fullinternsec.dto.main.CpHomeModel;

import it.csi.smplsec.fullinternsec.presentation.fullinternsec.security.*;

import it.csi.smplsec.fullinternsec.business.*;

import it.csi.smplsec.fullinternsec.presentation.fullinternsec.action.*;

import it.csi.smplsec.fullinternsec.presentation.fullinternsec.action.main.states.CpHomeScreenStates;

import it.csi.smplsec.fullinternsec.presentation.fullinternsec.interceptor.MethodProtection;

import it.csi.smplsec.fullinternsec.presentation.fullinternsec.interceptor.FatClientOnly;
import it.csi.smplsec.fullinternsec.presentation.uiutils.*;
import flexjson.JSON;

/**
 * CpHomeAction Action Class.
 *
 * @author GuiGen
 */
@Validation()
@Conversion()
public class CpHomeAction extends BaseAction<CpHomeModel>
		implements
			Preparable,
			ModelDriven<CpHomeModel> {

	/**
	 * Il modello del content panel.
	 * Viene riempito a fornte delle interazioni con il browser e viene passato allo
	 * strato di business.
	 */
	private CpHomeModel model;

	/**
	 * Il modello del content panel.
	 * Viene riempito a fornte delle interazioni con il browser e viene passato allo
	 * strato di business.
	 */
	public CpHomeModel getModel() {
		return model;
	}

	/**
	 * Il modello del content panel.
	 * Viene riempito a fornte delle interazioni con il browser e viene passato allo
	 * strato di business.
	 */
	@VisitorFieldValidator(message = "", appendPrefix = false)
	public void setModel(CpHomeModel modello) {
		this.model = modello;
	}

	/**
	 * Il metodo setSession() viene ridefinito in modo che venga asosciato all'oggetto
	 * model.
	 * N.B: il model deve essere creato in precedenza, altrimenti l'impostazione non 
	 * e' possibile. 
	 * Per questo motivo esso viene creato in questo (se non già esistente).
	 */
	@Override
	public void setSession(Map session) {
		// implementazione standard di SessionAware
		super.setSession(session);
		// creo una nuova istanza di modello, se gia' non esiste 
		if (model == null) {
			model = new CpHomeModel();
		}
		// associo la sessione applicativa al modello, in modo che
		// possa implementare l'accesso agli application data
		// di scope session/same page
		model.setSession(session);
	}

	/**
	 * contiene le coppie <codice location, comando di jump corrispondente>
	 */
	private HashMap<String, JumpExtCommand> jumpExtCommands = new HashMap<String, JumpExtCommand>();

	/**
	 * contiene le coppie <codice location, comando di jump corrispondente>
	 */
	public HashMap<String, JumpExtCommand> getJumpExtCommands() {
		return jumpExtCommands;
	}

	/**
	 * contiene le coppie <codice location, comando di jump corrispondente>
	 */
	public void setJumpExtCommands(
			HashMap<String, JumpExtCommand> jumpExtCommands) {
		this.jumpExtCommands = jumpExtCommands;
	}

	/**
	 * nome del content panel
	 */
	private static final String CP_NAME = "cpHome";

	private static final String URL_BACK_COMMAND = "/base/main/" + CP_NAME;

	/**
	 * classe model associata al ContentPanel
	 */
	public Class modelClass() {
		return it.csi.smplsec.fullinternsec.dto.main.CpHomeModel.class;
	}

	/**
	 * I singoli eventi sui singoli widget sono gestiti dai metodi specifici   
	 * @return SUCCESS.
	 */
	@SkipValidation
	public String execute() throws CommandExecutionException {
		// esegue eventuali comandi di clear appdata
		ICommand clearCmd = (ICommand) session
				.get(PENDING_CLEAR_COMMAND_ATTRIBUTE);
		if (clearCmd != null) {
			// esegue la rimozione degli appdata a scope page, tramite l'apposito comando
			clearCmd.doCommand(this);
			// elimina il comando dalla sessione, in quanto ormai eseguito
			session.remove(PENDING_CLEAR_COMMAND_ATTRIBUTE);
		}

		// imposta il nome del content panel corrente
		setCurrentContentPanel(CP_NAME);
		return SUCCESS;
	}

	//////////////////////////////////////////////////////////////////////////////////
	/// metodi specifici per la gestione del singolo tipo di evento sul singolo widget
	/// contenuto nel contentPanel
	/// metodo: handle<nomeWidget>_<NOME_EVENTO>
	/// es: handletreeVoci_CLICKED
	//////////////////////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////////////////////
	/// metodo di data providing sull'intero ContentPanel
	/// metodo: provide_CPDATA
	//////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////////////
	/// metodi di data providing sui widget dotati di multi data binding
	/// contenuti nel contentPanel
	/// metodo: provide<nomeWidget>_<tipologia dati>
	/// es: provideCbComuni_DATASET
	//////////////////////////////////////////////////////////////////////////////////

	/**
	 * Gestione della validazione
	 */
	public void validate() {
		/*PROTECTED REGION ID(R-1459633069) ENABLED START*/
		/* Inserire la validazione */
		/*PROTECTED REGION END*/
	}

	protected Map<String, UISecConstraint> allVisibilityConstraints = null;
	protected Map<String, UISecConstraint> allOnOffConstraints = null;

	public void setCPCommandInitCpHome(java.lang.Boolean value) {
		getSession().put("CPCommandInitCpHome", value);
	}

	public java.lang.Boolean getCPCommandInitCpHome() {
		return (java.lang.Boolean) (getSession().get("CPCommandInitCpHome"));
	}

	/**
	 * Metodo di preparazione della schermata/action
	 */
	public void prepare() throws CommandExecutionException {
		super.prepare();

		// cancellazione eventuale degli errori di conversione non desiderati
		clearConversionErrorsIfSkipValidation();

		// caricamento struttura di constraints
		if (allVisibilityConstraints == null)
			allVisibilityConstraints = getPageVisibilityUIConstraints();
		if (allOnOffConstraints == null)
			allOnOffConstraints = getPageONOFFUIConstraints();

		ActionContext ctx = ActionContext.getContext();
		String methodName = ctx.getActionInvocation().getProxy().getMethod();

		boolean onRefreshEvent = true;

	}

	// ridefinizione dei metodi di verifica visibilita'/validazione
	// per supportare i security check

	/**
	 * Restituisce true se il widget e' abilitato.
	 * Il risultato e' condizionato da:
	 * - stato di default
	 * - stato comandato da OnOffCommand
	 * - stato comandato da ScreenStateCommand
	 * - security constraint
	 * @param cpName nome del content panel
	 * @param widgShortName nome del widget 
	 */
	public boolean isWidgetDisabled(String cpName, String widgShortName) {
		// recupero l'elenco del security constraint preparati in fase di
		// inizializzazione del pannello
		UISecConstraint ctr = allOnOffConstraints.get(widgShortName);
		if (ctr != null) {
			try {
				// se sono presenti dei constraint, li eseguo per conoscere lo stato
				// di abilitazione del widget
				return !ctr.verifyConstraint(session,
						UISecConstraint.ONOFF_CONSTRAINED_BEHAVIOR,
						getSpringSecurityHelper());
			} catch (BEException ex) {
				log.error("[CpHomeAction::isWidgetDisabled] errore durante verifica->disable");
				return true; // forzo la DISABILITAZIONE
			}
		} else {
			// se non sono presenti constraint vale l'implementazione di default
			return super.isWidgetDisabled(cpName, widgShortName);
		}
	}

	/**
	 * Restituisce true se il widget e' visibile.
	 * Il risultato e' condizionato da:
	 * - stato di default
	 * - stato comandato da VisibilityCommand
	 * - stato comandato da ScreenStateCommand
	 * - security constraint
	 * @param cpName nome del content panel
	 * @param widgShortName nome del widget 
	 */
	public boolean isWidgetVisible(String cpName, String widgShortName) {
		// recupero l'elenco del security constraint preparati in fase di
		// inizializzazione del pannello
		UISecConstraint ctr = allVisibilityConstraints.get(widgShortName);
		if (ctr != null) {
			try {
				// se sono presenti dei constraint, li eseguo per conoscere lo stato
				// di visibilita' del widget
				return ctr.verifyConstraint(session,
						UISecConstraint.VISIB_CONSTRAINED_BEHAVIOR,
						getSpringSecurityHelper());
			} catch (BEException ex) {
				log.error("[CpHomeAction::isWidgetVisible] errore durante verifica->hide");
				return false; // forzo l'invisibilita'
			}
		} else {
			// se non sono presenti constraint vale l'implementazione di default
			return super.isWidgetVisible(cpName, widgShortName);
		}
	}

	protected Map<String, UISecConstraint> getPageVisibilityUIConstraints() {
		Map<String, UISecConstraint> allConstraints = new HashMap<String, UISecConstraint>();

		// constraint fittizio per mnuView
		UISecConstraint mnuView_defaultVisib_ctr =

		new DummyUISecConstraint("cpHome", "mnuView",
				UISecConstraint.VISIB_CONSTRAINED_BEHAVIOR, true, true);

		//// ele nco di tutti i constraint dell'elemento 
		UISecConstraint[] mnuView_constraints = new UISecConstraint[]{mnuView_defaultVisib_ctr};
		//// constraint complessivo che racchiude ricorsivamente i singoli constraints
		UISecConstraint mnuView_ctr = new ComplexUISecConstraint(
				mnuView_constraints);
		//// inserisco il constraint complessivo nella mappa <nome elemento, constraints dell'elemento>
		allConstraints.put("mnuView", mnuView_ctr);
		return allConstraints;
	}

	protected Map<String, UISecConstraint> getPageONOFFUIConstraints() {
		Map<String, UISecConstraint> allConstraints = new HashMap<String, UISecConstraint>();

		// constraint fittizio per mnuView
		UISecConstraint mnuView_defaultOnoff_ctr =

		new DummyUISecConstraint("cpHome", "mnuView",
				UISecConstraint.ONOFF_CONSTRAINED_BEHAVIOR, true, true);

		//// ele nco di tutti i constraint dell'elemento 
		UISecConstraint[] mnuView_constraints = new UISecConstraint[]{mnuView_defaultOnoff_ctr};
		//// constraint complessivo che racchiude ricorsivamente i singoli constraints
		UISecConstraint mnuView_ctr = new ComplexUISecConstraint(
				mnuView_constraints);
		//// inserisco il constraint complessivo nella mappa <nome elemento, constraints dell'elemento>
		allConstraints.put("mnuView", mnuView_ctr);
		return allConstraints;
	}

	/**
	 * comandi da eseguire prima di ciascun evento
	 */
	protected void doBeforeEventCommand() throws CommandExecutionException {
		// comandi da eseguire prima dei comandi associati ad ogni evento

	}

	/**
	 * comandi da eseguire dopo ciascun evento
	 */
	protected void doAfterEventCommand() throws CommandExecutionException {
		// comandi da eseguire prima dei comandi associati ad ogni evento

	}

	/**  */
	protected void dumpModel(boolean pre) {
		log.debug("[CpHomeAction::dumpmodel] START");

		log.debug("[CpHomeAction::dumpmodel] #### DUMP del model della action "
				+ this.getClass()
				+ (pre ? " prima dell'azione" : " dopo l'azione"));
		log.debug("[CpHomeAction::dumpmodel] [a] campi pubblici del model");
		try {
			java.beans.BeanInfo bi = java.beans.Introspector.getBeanInfo(this
					.getClass());
			java.beans.PropertyDescriptor[] props = bi.getPropertyDescriptors();
			for (int i = 0; i < props.length; i++) {
				java.beans.PropertyDescriptor pd = props[i];
				java.lang.reflect.Method m = pd.getReadMethod();
				if (m != null) {
					Object pval = m.invoke(this, new Object[]{});
					log.debug("[CpHomeAction::dumpmodel] " + pd.getName() + ":"
							+ pval);
				}
			}
		} catch (IllegalAccessException e) {
			log.error("[CpHomeAction::dumpmodel] Errore nel dump" + e
					+ ", ignoro");
		} catch (InvocationTargetException e) {
			log.error("[CpHomeAction::dumpmodel] Errore nel dump" + e
					+ ", ignoro");
		} catch (IntrospectionException e) {
			log.error("[CpHomeAction::dumpmodel] Errore nel dump" + e
					+ ", ignoro");
		}
		log.debug("[CpHomeAction::dumpmodel] [b] stato dei widget");
		Object cpWidgetStatus = session.get("cpHome");
		log.debug("[CpHomeAction::dumpmodel] " + cpWidgetStatus);
		log.debug("[CpHomeAction::dumpmodel] [c] sessione");
		log.debug("[CpHomeAction::dumpmodel] " + session);
	}

	static final String PENDING_CLEAR_COMMAND_ATTRIBUTE = "_pending_clear_command_";
	/**
	 *	Metodo per la rimozione dalla sessione degli application data a scope
	 *  SAME_PAGE. 
	 */
	public void clearPageScopedAppData(String targetContentPanelName) {
		// nothing to clear...
	}

	/**
	 * inizializza la struttura dei command da eseguire per ciascun event handler 
	 * di ciascun widget
	 */
	protected final ICommand initCommand(String sourceWidget, String eventType) {
		HashMap<String, HashMap<String, ICommand>> cmdsByWidget = new HashMap<String, HashMap<String, ICommand>>();

		ICommand ris = cmdsByWidget.get(sourceWidget).get(eventType);
		if (ris != null)
			return ris;
		else
			return new NOPCommand();
	}

	@SkipValidation
	public String handleChangeTab() {
		if (this.hasActionErrors() || this.hasFieldErrors() || this.hasErrors())
			return INPUT;
		else {
			session.put(getModel().getSelectedTabKey(), getModel()
					.getSelectedTabValue());
			return SUCCESS;
		}
	}

}
