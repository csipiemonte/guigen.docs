package it.csi.smplsec.fullinternsec.dto;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Hashtable;
import java.util.List;

/**
 * classe di utilita' varia per operare sugli oggetti DTO.
 */
public class DTOUtils {

	/**
	 * singleton
	 */
	private static DTOUtils _instance;

	static {
		// creazione del singleton
		_instance = new DTOUtils();
	}

	/**
	 * singleton instance
	 */
	public static DTOUtils getInstance() {
		return _instance;
	}

	/**
	 * Effettua una verifica di uguaglianza in profondita' tra i due
	 * oggetti in input
	 * @param o1
	 * @param o2
	 */
	public boolean deepEquals(Object o1, Object o2) {
		if ((o1 == null || o2 == null) && (o1 != null || o2 != null)) {
			// se uno solo dei due oggetti e' nullo allora non 
			// possono essere uguali
			return false;
		} else if (List.class.isAssignableFrom(o1.getClass())) {
			// se sono array effettuo la verifica specifica
			return deepEqualsArray(o1, o2);
		} else if (!(o1.getClass().equals(o2.getClass()))) {
			// se i due oggetti non sono della stessa classe
			// non possono essere uguali
			return false;
			// else: stesso tipo e nessuno dei due nullo
		} else if (o1 instanceof Integer || o1 instanceof Long
				|| o1 instanceof Float || o1 instanceof Double
				|| o1 instanceof String || o1 instanceof Byte
				|| o1 instanceof Boolean) {
			// se sono tipi semplici utilizzo la funzione equals prevista
			// per quei tipi
			return o1.equals(o2);
		} else {
			// se sono oggetti complessi effettuo la verifica specifica
			return deepEqualsBean(o1, o2);
		}
	}

	/**
	 * verifica di uguaglianza specifica per bean
	 * @param o1
	 * @param o2
	 */
	private boolean deepEqualsBean(Object o1, Object o2) {
		BeanInfo bi;
		try {
			// l'accesso agli oggetti avviene mediante introspection
			bi = Introspector.getBeanInfo(o1.getClass());
		} catch (IntrospectionException e) {
			throw new IllegalArgumentException("errore in lettura campi di "
					+ o1.getClass() + ":" + e);
		}
		PropertyDescriptor[] pds = bi.getPropertyDescriptors();
		for (int i = 0; i < pds.length; i++) {
			PropertyDescriptor currPD = pds[i];
			// ottengo il metodo di lettura della property corrente dai metadati
			Method getter = currPD.getReadMethod();
			// ottengo il metodo di scrittura della property corrente dai metadati
			Method setter = currPD.getWriteMethod();
			if (getter != null && setter != null) {
				// se la property non e' read only..
				try {
					// valore della property nell'oggetto 1
					Object v1 = getter.invoke(o1, new Object[]{});
					// valore della property nell'oggetto 2
					Object v2 = getter.invoke(o2, new Object[]{});
					// richiamo ricorsivamente la verifica sui due valori
					if (!deepEquals(v1, v2))
						return false; // basta uno diverso => false
				} catch (IllegalAccessException e) {
					throw new IllegalArgumentException(
							"errore in lettura campi di " + o1.getClass() + ":"
									+ e);
				} catch (InvocationTargetException e) {
					throw new IllegalArgumentException(
							"errore in lettura campi di " + o1.getClass() + ":"
									+ e);
				}
			}
		}
		return true;
	}

	/**
	 * metodo di verifica di uguaglianza profonda, specifico per oggetti di
	 * tipo array
	 * @param o1
	 * @param o2
	 */
	private boolean deepEqualsArray(Object o1, Object o2) {
		List l1 = (List) o1;
		List l2 = (List) o2;
		if (l1.size() != l2.size()) {
			// se le due collezioni non hanno lo stesso numero di elementi
			// non possono essere uguali, percio' non proseguo la verifica
			// sugli elementi
			return false;
		} else {
			// se le due collezioni hanno lo stesso numero di elementi proseguo
			// la verifica sui singoli elementi
			for (int i = 0; i < l1.size(); i++) {
				// oggetto i-esimo della prima collezione
				Object curr1 = l1.get(i);
				// oggetto i-esimo della seconda collezione
				Object curr2 = l2.get(i);
				// effettuo la verifica sulla coppia di elementi, sempre tramite
				// il metodo deepEquals
				if (!deepEquals(curr1, curr2))
					return false; // al primo diverso mi fermo
			}
			return true;
		}
	}
}
